/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package connect4cpt;

import static connect4cpt.Score.intP1List;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

/**
 *
 * Author: Mithran Roy
 * Date: August 25th, 2020
 * Class which reads from a file to give the high scores of player 1 and player 2
 */

// INHERITANCE from the score class
public class ScoreGiver extends Score{

    // Constructor for this class
    public ScoreGiver(int intPNumber) {
         //Callling the the constructor from the parent class
        super(intPNumber);
    }
    
    // get score method for the p1 score class
    /**
     * 
     * @param intPNum is the player number
     * @return the array list with all the corresponding scores
     */
    public ArrayList getList(int intPNum){
        
        if (intPNum == 1){
            ArrayList<Integer> intP1List = new ArrayList<Integer>();
        } else if (intPNum == 2){
            ArrayList<Integer> intP2List = new ArrayList<Integer>();
        }  
        
        try{
            // Determining file reader on who's scores they want
            FileReader fr = new FileReader("p1Scores.txt");
            if (intPNum == 1){
                fr = new FileReader("p1Scores.txt");
            } else {
                fr = new FileReader("p2Scores.txt");
            }            
            BufferedReader br = new BufferedReader(fr);
            String strLine = br.readLine();//All the files keep
            //a system generated character to terminate a new line
            //when the line that read is a null then that's the end of tbe file
            
            for (int i = 0; i < 12; i++){
                if (intPNum == 1){
                    intP1List.add(Integer.parseInt(strLine));
                } else if (intPNum == 2){
                    intP2List.add(Integer.parseInt(strLine));                
                }               
                
                strLine = br.readLine();
            }
            
            br.close();
        }
        catch (IOException e){}
        if (intPNum == 1){
            return intP1List;
        } else{
            return intP2List;
        }
        
    }
}
