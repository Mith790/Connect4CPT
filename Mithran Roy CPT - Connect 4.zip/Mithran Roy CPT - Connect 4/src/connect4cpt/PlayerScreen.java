/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package connect4cpt;
//import static connect4cpt.OpeningScreen.strP1Name;
//import static connect4cpt.OpeningScreen.strP2Name;
import connect4cpt.OpeningScreen.returnAIMode;
import java.applet.Applet;
import java.awt.Color;
import java.awt.FlowLayout; // specifies how components are arranged
import java.awt.Font;
import javax.swing.JFrame; // provides basic window features
import javax.swing.JLabel; // displays text and images
import javax.swing.SwingConstants; // common constants used with swing
import javax.swing.Icon; // interface used byto manipulate images
import javax.swing.ImageIcon; // loads images
import javax.swing.*;
import java.awt.event.*;
import java.text.DecimalFormat; // This library allows us to do rounding
import java.util.ArrayList;
import java.io.*;
import java.util.Collections;
import javax.swing.border.Border;
/**
 *
 * Author: Mithran Roy
 * Date: August 25th, 2020
 * Program which opens the player 1 selection screen of the Connect 4 Game
 */
public class PlayerScreen extends JFrame implements ActionListener{
    JLabel lblTitle; // This is the Title Label which shows the title image
    JLabel lblCharacters; // This is the Characters Label which shows an image of the playable characters
    JLabel lblPlayer; // This is the Player Label which shows the player the selected character name
    JLabel lblPlayerNumber; // This is the label which informs the user which player is being selected
    JButton btnHome; // This is the button to bring up the opening screen    
    JButton btnBack; // This is the button to bring up the previous opening screen
    JButton btnNext; // This is the button to bring up the AI character selection screen
    JButton btnDracula; // This is the button to play as Dracula
    JButton btnKing; // This is the button to play as King
    JButton btnBob; // This is the button to play as Bob
    JButton btnNinja; // This is the button to play as Ninja
    JButton btnPirate; // This is the button to play as Pirate
    JButton btnJoel; // This is the button to play as Joel Miller
    JButton btnEllie; // This is the button to play as Ellie
    JButton btnMithran; // This is the button to play as Mithran
    JButton btnSarah; // This is the button to play as Sarah
    JButton btnChloe; // This is the button to play as Chloe
    JButton btnJess; // This is the button to play as Jess
    JButton btnMrJeg; // This is the button to play as Mr. Jeg
    ButtonGroup playerGroup; // This is a group to store all the player options
    
    JButton btnHelp; // This is the button to bring up the "how to play" screen
    JButton btnCredits; // This is the button which brings up the screen showing credits and image sources
    
    // Creating a boolean variable to track if AI mode on
    boolean isAIOn;
    // Creating a string variable to store the name of the first player or only player
    static String strP1SelectName = ""; // It is static so that it can be passed through a static method
    // Creating a string variable to store player 2 or AI name
    static String strP2SelectName = ""; // It is static so that it can be passed through a static method
    static String strPlayer1;
    
    // Importing the images to use
    ImageIcon title = new ImageIcon("chooseCharacter.png");
    ImageIcon characters = new ImageIcon("characters.png");
    ImageIcon dracula = new ImageIcon("draculaSmall.png");
    ImageIcon king = new ImageIcon("kingSmall.png");
    ImageIcon bob = new ImageIcon("manSmall.png");
    ImageIcon ninja = new ImageIcon("ninjaSmall.png");
    ImageIcon pirate = new ImageIcon("pirateSmall.png");
    ImageIcon joel = new ImageIcon("joelSmall.png");
    ImageIcon ellie = new ImageIcon("ellieSmall.png");
    ImageIcon mith = new ImageIcon("mithranSmall.png");
    ImageIcon sarah = new ImageIcon("womanSmall.png");
    ImageIcon chloe = new ImageIcon("girlSmall.png");
    ImageIcon jess = new ImageIcon("calmGirlSmall.png");
    ImageIcon mrJeg = new ImageIcon("mrJegSmall.png");
    ImageIcon next = new ImageIcon("next.png");
    ImageIcon back = new ImageIcon("back.png");
    ImageIcon home = new ImageIcon("home.png");
    ImageIcon newTitle = new ImageIcon("chooseAICharacter.png");
    //ImageIcon p1 = new ImageIcon("p1.png");
    
    public PlayerScreen(){
        super("Connect 4 Game Character Selection"); // This will be displayed in the Title Bar
        //Setting up the screen
        resize(1920, 1080);
        // Setting the frame layout
        setLayout(null);     
        
        strPlayer1 = strP1SelectName;
        strP1SelectName = "";
        
        
        // Setting up an instance of the Title label
        lblTitle = new JLabel();
        // Setting the size of the label
        lblTitle.setSize(1552, 320);
        // Choosing the location
        lblTitle.setLocation(184, 0);
        // Adding the title image to the label
        lblTitle.setIcon(title);
        // Adding the label to the JFrame
        add(lblTitle);
        
        
        // Calling static class from opening screen to check if AI mode is turned on
        returnAIMode ai = new returnAIMode();
        isAIOn = ai.getAIMode();
        
        // Only showing the player number label if AI mode if off
        if (isAIOn == false){
            // Setting up an instance of the Player Number label
            lblPlayerNumber = new JLabel();
            // Setting the size of the label
            lblPlayerNumber.setSize(406, 50);
            // Choosing the location
            lblPlayerNumber.setLocation(758, 325);
            // Setting the text in the Phrase One Label
            lblPlayerNumber.setText("PLAYER ONE");
            // Changing font and font size of label
            lblPlayerNumber.setFont(new Font("Baskerville Old Face", Font.BOLD, 60));
            // Adding the label to the JFrame
            add(lblPlayerNumber);
        }
        
        // Setting up an instance of the Dracula Button
        btnDracula = new JButton();
        // Setting up the size of the button
        btnDracula.setSize(250, 270);
        // Choosing the location
        btnDracula.setLocation(100, 380);
        // Adding the dracula image to the label
        btnDracula.setIcon(dracula);
        // Making the button listen to user
        btnDracula.setActionCommand("Dracula");
        btnDracula.addActionListener(this); // Makes this button react to action command
        // Adding the button to the JFrame
        add(btnDracula);
        
        // Setting up an instance of the King Button
        btnKing = new JButton();
        // Setting up the size of the button
        btnKing.setSize(250, 270);
        // Choosing the location
        btnKing.setLocation(394, 380);
        // Adding the king image to the label
        btnKing.setIcon(king);
        // Making the button listen to user
        btnKing.setActionCommand("King");
        btnKing.addActionListener(this); // Makes this button react to action command
        // Adding the button to the JFrame
        add(btnKing);
        
        // Setting up an instance of the Bob Button
        btnBob = new JButton();
        // Setting up the size of the button
        btnBob.setSize(250, 270);
        // Choosing the location
        btnBob.setLocation(688, 380);
        // Adding the bob image to the label
        btnBob.setIcon(bob);
        // Making the button listen to user
        btnBob.setActionCommand("Bob");
        btnBob.addActionListener(this); // Makes this button react to action command
        // Adding the button to the JFrame
        add(btnBob);
        
        // Setting up an instance of the Ninja Button
        btnNinja = new JButton();
        // Setting up the size of the button
        btnNinja.setSize(250, 270);
        // Choosing the location
        btnNinja.setLocation(982, 380);
        // Adding the ninja image to the label
        btnNinja.setIcon(ninja);
        // Making the button listen to user
        btnNinja.setActionCommand("Ninja");
        btnNinja.addActionListener(this); // Makes this button react to action command
        // Adding the button to the JFrame
        add(btnNinja);
        
        // Setting up an instance of the Pirate Button
        btnPirate = new JButton();
        // Setting up the size of the button
        btnPirate.setSize(250, 270);
        // Choosing the location
        btnPirate.setLocation(1276, 380);
        // Adding the pirate image to the label
        btnPirate.setIcon(pirate);
        // Making the button listen to user
        btnPirate.setActionCommand("Pirate");
        btnPirate.addActionListener(this); // Makes this button react to action command
        // Adding the button to the JFrame
        add(btnPirate);
        
        // Setting up an instance of the Joel Button
        btnJoel = new JButton();
        // Setting up the size of the button
        btnJoel.setSize(250, 270);
        // Choosing the location
        btnJoel.setLocation(1570, 380);
        // Adding the joel image to the label
        btnJoel.setIcon(joel);
        // Making the button listen to user
        btnJoel.setActionCommand("Joel");
        btnJoel.addActionListener(this); // Makes this button react to action command
        // Adding the button to the JFrame
        add(btnJoel);
        
        // Setting up an instance of the Ellie Button
        btnEllie = new JButton();
        // Setting up the size of the button
        btnEllie.setSize(250, 270);
        // Choosing the location
        btnEllie.setLocation(100, 670);
        // Adding the ellie image to the label
        btnEllie.setIcon(ellie);
        // Making the button listen to user
        btnEllie.setActionCommand("Ellie");
        btnEllie.addActionListener(this); // Makes this button react to action command
        // Adding the button to the JFrame
        add(btnEllie);
        
        // Setting up an instance of the Mithran Button
        btnMithran = new JButton();
        // Setting up the size of the button
        btnMithran.setSize(250, 270);
        // Choosing the location
        btnMithran.setLocation(394, 670);
        // Adding the mith image to the label
        btnMithran.setIcon(mith);
        // Making the button listen to user
        btnMithran.setActionCommand("Mithran");
        btnMithran.addActionListener(this); // Makes this button react to action command
        // Adding the button to the JFrame
        add(btnMithran);
        
        // Setting up an instance of the Sarah Button
        btnSarah = new JButton();
        // Setting up the size of the button
        btnSarah.setSize(250, 270);
        // Choosing the location
        btnSarah.setLocation(688, 670);
        // Adding the sarah image to the label
        btnSarah.setIcon(sarah);
        // Making the button listen to user
        btnSarah.setActionCommand("Sarah");
        btnSarah.addActionListener(this); // Makes this button react to action command
        // Adding the button to the JFrame
        add(btnSarah);
        
        // Setting up an instance of the Chloe Button
        btnChloe = new JButton();
        // Setting up the size of the button
        btnChloe.setSize(250, 270);
        // Choosing the location
        btnChloe.setLocation(982, 670);
        // Adding the chloe image to the label
        btnChloe.setIcon(chloe);
        // Making the button listen to user
        btnChloe.setActionCommand("Chloe");
        btnChloe.addActionListener(this); // Makes this button react to action command
        // Adding the button to the JFrame
        add(btnChloe);
        
        // Setting up an instance of the Jess Button
        btnJess = new JButton();
        // Setting up the size of the button
        btnJess.setSize(250, 270);
        // Choosing the location
        btnJess.setLocation(1276, 670);
        // Adding the jess image to the label
        btnJess.setIcon(jess);
        // Making the button listen to user
        btnJess.setActionCommand("Jess");
        btnJess.addActionListener(this); // Makes this button react to action command
        // Adding the button to the JFrame
        add(btnJess);
        
        // Setting up an instance of the Mr. Jeg Button
        btnMrJeg = new JButton();
        // Setting up the size of the button
        btnMrJeg.setSize(250, 270);
        // Choosing the location
        btnMrJeg.setLocation(1570, 670);
        // Adding the mrJeg image to the label
        btnMrJeg.setIcon(mrJeg);
        // Making the button listen to user
        btnMrJeg.setActionCommand("Mr. Jeg");
        btnMrJeg.addActionListener(this); // Makes this button react to action command
        // Adding the button to the JFrame
        add(btnMrJeg);
        
        // Setting up an instance of the Player JLabel
        lblPlayer = new JLabel();
        // Setting up the size of the label
        lblPlayer.setSize(566, 90);
            // Choosing the location
        lblPlayer.setLocation(677, 945);
        // Setting the text in the Player Label
        lblPlayer.setText("");
        // Changing font and font size of label
        lblPlayer.setFont(new Font("Garamond", Font.BOLD, 80));
        // Adding the label to the JFrame
        add(lblPlayer);
        
        // Setting up an instance of the Home Button
        btnHome = new JButton();
        // Setting up the size of the button
        btnHome.setSize(100, 100);
        // Choosing the location
        btnHome.setLocation(0, 0);
        // Adding the home image to the label
        btnHome.setIcon(home);        
        // Making the button listen to user
        btnHome.setActionCommand("Home");
        btnHome.addActionListener(this); // Makes this button react to action command
        // Adding the button to the JFrame
        add(btnHome);
        
        // Setting up an instance of the Back Button
        btnBack = new JButton();
        // Setting up the size of the button
        btnBack.setSize(400, 100);
        // Choosing the location
        btnBack.setLocation(0, 940);
        // Adding the back image to the label
        btnBack.setIcon(back);        
        // Making the button listen to user
        btnBack.setActionCommand("Back");
        btnBack.addActionListener(this); // Makes this button react to action command
        // Adding the button to the JFrame
        add(btnBack);
        
        // Setting up an instance of the Next Button
        btnNext = new JButton();
        // Setting up the size of the button
        btnNext.setSize(400, 100);
        // Choosing the location
        btnNext.setLocation(1500, 940);
        // Adding the next image to the label
        btnNext.setIcon(next);
        // Removing the border of the button
        Border emptyBorder = BorderFactory.createLineBorder(Color.white, 10);
        //btnNext.setBorder(emptyBorder);
        // Making the button listen to user
        btnNext.setActionCommand("Next");
        btnNext.addActionListener(this); // Makes this button react to action command
        // Adding the button to the JFrame
        add(btnNext);        
    }
    
public void actionPerformed (ActionEvent e){
    // Checking if Back button or Home button was clicked
    if(e.getActionCommand().equals("Back") || e.getActionCommand().equals("Home")){
        // Resetting the player name variable
        strP1SelectName = "";
        // Reopening the main menu screen
        OpeningScreen myFrame = new OpeningScreen();
        myFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);// When user clicks the close button
        // JFrame will automatically exit
        myFrame.setVisible(true); // Displaying the new JFrame
        this.dispose(); // Closing the currently open frame
    }
    
    // Checking if Next button was clicked
    else if(e.getActionCommand().equals("Next")){
        
        // If player has not chosen character, prompting them to choose a character
        if (strP1SelectName == ""){
            JOptionPane.showMessageDialog(null, "Please click on a character to select first");  
        }
        // Otherwise, opening the appropriate screen
        else {
            
            // Going to the AI selection screen if AI mode is turned on
            if (isAIOn){            
                AIScreen myFrame3 = new AIScreen();
                myFrame3.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                myFrame3.setVisible(true); // Displaying the new JFrame  
            }        

            // Going to the main game screen if AI is not turned on
            else{
                Player2Screen myFrame3 = new Player2Screen();
                myFrame3.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                myFrame3.setVisible(true); // Displaying the new JFrame  
            }

            this.dispose(); // Closing the currently open frame
        }        
    }
    
    // If any other button was clicked, the player name is assigned the name of button
    else{        
        strP1SelectName = e.getActionCommand();
    }
      
    // Regardless of what button was pressed, updating player name at bottom of screen
    // Show the character name if a character has been selected
    if (strP1SelectName != ""){
        lblPlayer.setText("Play as " + strP1SelectName + "?");
    }    
}

// A method which can be called by other classes to check the player name
static class returnPlayer1Name{
    // Creating a private string to store the player name
    private String strPlayer = strPlayer1;
    // Creating a method to return the string value
    public String getPlayer1(){
        return this.strPlayer;    
    }
    }
// A method which can be called by other classes to check the player 2 name
static class returnPlayer2Name{
    // Creating a private string to store the AI name
    private String strP2 = strP2SelectName;
    // Creating a method to return the string value
    public String getPlayer2(){
        return this.strP2;    
    }
    }
}
