/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package connect4cpt;

/**
 *
 * Author: Mithran Roy
 * Date: August 25th, 2020
 * Unedited class which was created by default when project was made
 */
public class Connect4CPT {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
