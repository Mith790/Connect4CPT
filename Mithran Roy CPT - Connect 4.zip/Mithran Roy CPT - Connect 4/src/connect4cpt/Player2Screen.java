/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package connect4cpt;

import java.awt.event.ActionEvent;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

/**
 *
 * Author: Mithran Roy
 * Date: August 25th, 2020
 * Program which opens the player 2 selection screen of the Connect 4 Game
 */
public class Player2Screen extends PlayerScreen{
    
    public Player2Screen(){        
        // Changing the text of the player number label
        lblPlayerNumber.setText("PLAYER TWO");
        // Changing the size of the label so that all the new text is visible
        lblPlayerNumber.setSize(428, 50);
        //Changing the location of the player number label so it as still centred
        lblPlayerNumber.setLocation(746, 325);
        
        // Note to self: Maybe put this in an abstract class
        // Disable the character which was selected as player
            if (strPlayer1.equals("Dracula")){
            btnDracula.setEnabled(false); // Deactivating button
        } else if (strPlayer1.equals("King")){
            btnKing.setEnabled(false); // Deactivating button
        } else if (strPlayer1.equals("Bob")){
            btnBob.setEnabled(false); // Deactivating button
        } else if (strPlayer1.equals("Ninja")){
            btnNinja.setEnabled(false); // Deactivating button
        } else if (strPlayer1.equals("Pirate")){
            btnPirate.setEnabled(false); // Deactivating button
        } else if (strPlayer1.equals("Joel")){
            btnJoel.setEnabled(false); // Deactivating button
        } else if (strPlayer1.equals("Ellie")){
            btnEllie.setEnabled(false); // Deactivating button
        } else if (strPlayer1.equals("Mithran")){
            btnMithran.setEnabled(false); // Deactivating button
        } else if (strPlayer1.equals("Sarah")){
            btnSarah.setEnabled(false); // Deactivating button
        } else if (strPlayer1.equals("Chloe")){
            btnChloe.setEnabled(false); // Deactivating button
        } else if (strPlayer1.equals("Jess")){
            btnJess.setEnabled(false); // Deactivating button
        } else {
            btnMrJeg.setEnabled(false); // Deactivating button
        }
            
    }
    public void actionPerformed (ActionEvent e){
    // Checking if Home button was clicked
    if(e.getActionCommand().equals("Home")){
        // Resetting the player 1 name and player 2 name variables
        strP1SelectName = "";
        strP2SelectName = "";
        // Reopening the main menu screen
        OpeningScreen myFrame = new OpeningScreen();
        myFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // When user clicks the close button
        // JFrame will automatically exit
        myFrame.setVisible(true); // Displaying the new JFrame
        this.dispose(); // Closing the currently open frame
    }
    
    // Checking if Next button was clicked
    if(e.getActionCommand().equals("Next")){
        // If player has not chosen character, prompting them to choose a character
        if (strP2SelectName == ""){
            JOptionPane.showMessageDialog(null, "Please click on a character to select first");  
        }
        // Otherwise, opening the main game screen
        else{
            GameScreen myFrame4 = new GameScreen();
            myFrame4.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            myFrame4.setVisible(true); // Displaying the new JFrame
            this.dispose(); // Closing the currently open frame  
        }        
    }
    
    // Checking if Back button was clicked
    else if(e.getActionCommand().equals("Back")){
        // Resetting the player 1 name and player 2 name variables
        strP1SelectName = "";
        strP2SelectName = "";
        PlayerScreen myFrame2 = new PlayerScreen();
        myFrame2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        myFrame2.setVisible(true); // Displaying the new JFrame 
        this.dispose(); // Closing the currently open frame
    }
    
    // If any other button was clicked, the player 2 name is assigned the name of button
    else{
        strP2SelectName = e.getActionCommand();                
    }
    
    // Regardless of what button was pressed, updating player name at bottom of screen
    // Show the Player 2 name if a character has been selected
    if (strP2SelectName != ""){
        lblPlayer.setText("Play as " + strP2SelectName + "?");    
    }
}
}
