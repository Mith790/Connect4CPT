/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package connect4cpt;
import java.awt.event.ActionListener;
import javax.swing.JFrame; // provides basic window features
import javax.swing.JLabel; // displays text and images
import javax.swing.*;
/**
 *
 * Author: Mithran Roy
 * Date: August 25th, 2020
 * An abstract class which has characteristics which will pass on to every screen
 */
public abstract class AbstractScreen extends JFrame implements ActionListener{
    JLabel lblImage; // This is the label which shows the image with the source
    JButton btnHome; // This is the button to bring up the opening screen
    
    ImageIcon credits = new ImageIcon("creditsList.png");
    ImageIcon home = new ImageIcon("home.png");
    
    // Creating boolean variable to track if AI mode is on
    boolean isAIOn;
    // Creating boolean variables to keep track of AI difficulty
    boolean isEasyModeOn, isMedModeOn;
    // Creating a string variable to keep track of the player name
    String strPlayerName;
    
    // Creating method to draw the screen
    public AbstractScreen(){
    super("Connect 4 Credits Screen"); // This will be displayed in the Title Bar
    //Setting up the screen
    resize(1920, 1080);
    // Setting the frame layout
    setLayout(null);
    
    // Setting up an instance of the Home Button
    btnHome = new JButton();
    // Setting up the size of the button
    btnHome.setSize(100, 100);
    // Choosing the location
    btnHome.setLocation(1810, 0);
    // Adding the home image to the label
    btnHome.setIcon(home);        
    // Making the button listen to user
    btnHome.setActionCommand("Home");
    btnHome.addActionListener(this); // Makes this button react to action command
    // Adding the button to the JFrame
    add(btnHome);
        
    }
    
    // Method which will send a pop up message
    public abstract void popUp();
}
