/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package connect4cpt;

import javax.swing.JFrame;

/**
 *
 * Author: Mithran Roy
 * Date: August 25th, 2020
 * Program to test JFrame
 */
public class JFrameTester {
    public static void main(String [] args){
        OpeningScreen myFrame = new OpeningScreen();
        myFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // When user clicks the close button
        // JFrame will automatically exit
        myFrame.setVisible(true); // Displaying the JFrame
    }
}
