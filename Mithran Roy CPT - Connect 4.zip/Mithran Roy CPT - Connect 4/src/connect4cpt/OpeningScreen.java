/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package connect4cpt;
import java.applet.Applet;
import java.awt.Color;
import java.awt.FlowLayout; // specifies how components are arranged
import java.awt.Font;
import javax.swing.JFrame; // provides basic window features
import javax.swing.JLabel; // displays text and images
import javax.swing.SwingConstants; // common constants used with swing
import javax.swing.Icon; // interface used byto manipulate images
import javax.swing.ImageIcon; // loads images
import javax.swing.*;
import java.awt.event.*;
import java.text.DecimalFormat; // This library allows us to do rounding
import java.util.ArrayList;
import java.io.*;
import java.util.Collections;
import javax.swing.border.Border;
import javax.swing.JOptionPane;

/**
 *
 * Author: Mithran Roy
 * Date: August 25th, 2020
 * Program which opens the opening screen of the Connect 4 Game
 */
public class OpeningScreen extends JFrame implements ActionListener{
    JLabel lblTitle; // This is the Title Label which shows the title image
    JLabel lblCharacters; // This is the Characters Label which shows an image of the playable characters
    JLabel lblHi; // This is a label which shows a bitmoij of me waving
    JButton btnStart; // This is the button to bring up the character selection screen
    JButton btnHelp; // This is the button to bring up the "how to play" screen
    JButton btnCredits; // This is the button which brings up the screen showing credits and image sources
    
    // Creating boolean variable to track if AI mode is on
    static boolean isAIOn; // It is static so that it can be passed through a static method
    // Creating a string variable which tracks the AI difficulty level
    static String strDifficulty = ""; // It is static so that it can be passed through a static method
    // Creating a string variable to store the name of the selected player 1
    //static String strP1Name; // It is static so that it can be passed through a static method
    // Creating a string variable to store the name of the selected player 2 or AI
    //static String strP2Name; // It is static so that it can be passed through a static method
    
    // Importing the images to use
    ImageIcon title = new ImageIcon("title.png");
    ImageIcon start = new ImageIcon("start.png");
    ImageIcon help = new ImageIcon("help.png");
    ImageIcon credits = new ImageIcon("credits.png");
    ImageIcon characters = new ImageIcon("characters.png");
    ImageIcon hi = new ImageIcon("hi.png");
    
public OpeningScreen(){
    super("Connect 4 Game Start Menu"); // This will be displayed in the Title Bar
    //Setting up the screen
    resize(1920, 1080);
    // Setting the frame layout
    setLayout(null);
    
    // Setting up an instance of the Title label
    lblTitle = new JLabel();
    // Setting the size of the label
    lblTitle.setSize(760, 240);
    // Choosing the location
    lblTitle.setLocation(580, 0);
    // Adding the title image to the label
    lblTitle.setIcon(title);
    // Adding the label to the JFrame
    add(lblTitle);
    
    // Setting up an instance of the Characters label
    lblCharacters = new JLabel();
    // Setting the size of the label
    lblCharacters.setSize(585, 525);
    // Choosing the location
    lblCharacters.setLocation(52, 300);
    // Adding the characters image to the label
    lblCharacters.setIcon(characters);
    // Adding the label to the JFrame
    add(lblCharacters);
    
    // Setting up an instance of the Hi label
    lblHi = new JLabel();
    // Setting the size of the label
    lblHi.setSize(362, 686);
    // Choosing the location
    lblHi.setLocation(1250, 300);
    // Adding the characters image to the label
    lblHi.setIcon(hi);
    // Adding the label to the JFrame
    add(lblHi);
    
    // Setting up an instance of the Start Button
    btnStart = new JButton();
    // Setting up the size of the button
    btnStart.setSize(480, 150);
    // Choosing the location
    btnStart.setLocation(720, 300);
    // Adding the start image to the label
    btnStart.setIcon(start);
    // Making the button listen to user
    btnStart.setActionCommand("Start");
    btnStart.addActionListener(this); // Makes this button react to action command
    // Adding the button to the JFrame
    add(btnStart);
    
    // Setting up an instance of the Help Button
    btnHelp = new JButton();
    // Setting up the size of the button
    btnHelp.setSize(480, 174);
    // Choosing the location
    btnHelp.setLocation(720, 500);
    // Adding the help image to the label
    btnHelp.setIcon(help);
    // Making the button listen to user
    btnHelp.setActionCommand("Help");
    btnHelp.addActionListener(this); // Makes this button react to action command
    // Adding the button to the JFrame
    add(btnHelp);
    
    // Setting up an instance of the Credits Button
    btnCredits = new JButton();
    // Setting up the size of the button
    btnCredits.setSize(480, 160);
    // Choosing the location
    btnCredits.setLocation(720, 724);
    // Adding the help image to the label
    btnCredits.setIcon(credits);
    // Making the button listen to user
    btnCredits.setActionCommand("Credits");
    btnCredits.addActionListener(this); // Makes this button react to action command
    // Adding the button to the JFrame
    add(btnCredits);
}
public void actionPerformed (ActionEvent e){
    // Checking if Start button was clicked
        if(e.getActionCommand().equals("Start")){
            // Resetting the player name and AI name variables
            //strP1Name = "";
            //strP2Name = "";            
            // Telling user to choose the game mode
            String[] strOptions = {"Two-Player Mode", "AI Mode"}; // Array of options
            ImageIcon icon = new ImageIcon("mithranTransparent.png");
            String strDecision = (String)JOptionPane.showInputDialog(null, "Would you like to play in AI Mode or Two-Player Mode?",
                    "Mode Selection", JOptionPane.QUESTION_MESSAGE, icon, strOptions, strOptions[1]);
            
            // Making the isAIOn variable true if player chose to play in AI mode
            if (strDecision != null){
                if (strDecision.equals("AI Mode")){
                isAIOn = true;            
                // Telling user to choose the game mode
                String[] strChoices = {"Easy", "Medium", "Hard"}; // Array of options
                ImageIcon pic = new ImageIcon("mithranTransparent.png");
                String strChoice = (String)JOptionPane.showInputDialog(null, "Please choose a difficulty level",
                    "Mode Selection", JOptionPane.QUESTION_MESSAGE, icon, strChoices, strChoices[1]);
                
                // Modifying the string variable tracking difficulty to the choice made by user if they responded
                if (strChoice != null){
                    strDifficulty = strChoice;
                } else {
                    strDifficulty = "";
                }                
        }
            else {
                isAIOn = false;
            }
            
            // Only going to the next screen if player completes all required answers
            if (isAIOn == true && strDifficulty != "" || isAIOn == false){
                PlayerScreen myFrame2 = new PlayerScreen();
                myFrame2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                myFrame2.setVisible(true); // Displaying the new JFrame
                this.dispose(); // Closing the currently open frame
            }
            }
                        
        }
    // Checking if Help button was clicked
        if(e.getActionCommand().equals("Help")){
            HelpScreen myFrame2 = new HelpScreen();
            myFrame2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            myFrame2.setVisible(true); // Displaying the new JFrame
            this.dispose(); // Closing the currently open frame
        }
        // Checking if Credits button was clicked
        if(e.getActionCommand().equals("Credits")){
            CreditsScreen myFrame2 = new CreditsScreen();
            myFrame2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            myFrame2.setVisible(true); // Displaying the new JFrame
            this.dispose(); // Closing the currently open frame
        }
}
// A method which can be called by other classes to check if AI mode was turned on
static class returnAIMode{
    // Creating a private boolean variable to track if AI is turned on
    private boolean isAI = isAIOn;
    // Creating a private string variable to track AI difficulty
    private String strAIDif = strDifficulty;
    // Creating a method to return the boolean value
    public Boolean getAIMode(){
        return this.isAI;    
    }
    public String getAIDif(){
        return this.strAIDif;
    }
}
}
