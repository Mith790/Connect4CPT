/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package connect4cpt;

import static connect4cpt.GameScreen.intWinTracker;
import static connect4cpt.GameScreen.p1Arr;
import static connect4cpt.GameScreen.p2Arr;
import static connect4cpt.GameScreen.strP1Name;
import static connect4cpt.GameScreen.strP2Name;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextArea;

/**
 *
 * Author: Mithran Roy
 * Date: August 25th, 2020
 * Program which displays the game over splash screen and also the top high score through selection sorting
 */
public class GameOverScreen extends JFrame implements ActionListener{
    JLabel lblTitle; // This is the Title Label which shows the title image
    JLabel lblPhrase; // This is the Phrase Label says who the winner is
    JButton btnHome; // This is the button to bring up the opening screen
    JTextArea txtP1Output; // This is where the scores for p1 will be outputted
    JTextArea txtP2Output; // This is where the scores for p1 will be outputted
    
    // Importing the image for the home button
    ImageIcon home = new ImageIcon("home.png");
    // Importing the game over image
    ImageIcon title = new ImageIcon("gameOver.png");
    
    // Creating array lists to store the high scores of the players
    // Creating a 1d array with the corresponding character names
    String[] nameArr = {"Dracula", "King", "Bob", "Ninja", "Pirate", "Joel", "Ellie", "Mithran", "Sarah", "Chloe", "Jess", "Mr. Jeg"};
    String[] name2Arr = nameArr.clone(); // Creating a copy so both can be manipulated seperately
    // Creating a string variable for each output
    String strOutput1 = "";
    String strOutput2 = "";
    
    public GameOverScreen(){
        super("Connect 4 Game Over Screen"); // This will be displayed in the Title Bar
        //Setting up the screen
        resize(1920, 1080);
        //Creating a colour to match background with RGB values
        Color gray = new Color(238, 238, 238);
        // Setting the frame layout
        setLayout(null);
        
        // Setting up an instance of the Title label
        lblTitle = new JLabel();
        // Setting the size of the label
        lblTitle.setSize(760, 300);
        // Choosing the location
        lblTitle.setLocation(580, 50);
        // Adding the title image to the label
        lblTitle.setIcon(title);
        // Adding the label to the JFrame
        add(lblTitle);
        
        // Setting up an instance of the Phrase label
        lblPhrase = new JLabel();
        // Setting the size of the label
        lblPhrase.setSize(860, 300);
        // Choosing the location
        lblPhrase.setLocation(530, 300);
        // Setting the text in the label according to who won
        if(intWinTracker == 1){
            lblPhrase.setText("Congratulations Player 1, you win!");
        } else if (intWinTracker == 2){
            lblPhrase.setText("Congratulations Player 2, you win!");
        } else {
            lblPhrase.setText("It was a tie!");
            lblPhrase.setLocation(800, 300);
        }        
        // Changing font and font size of label
        lblPhrase.setFont(new Font("Helvetica", Font.BOLD, 50));
        // Adding the label to the JFrame
        add(lblPhrase);
        
        // Setting up an instance of the Home Button
        btnHome = new JButton();
        // Setting up the size of the button
        btnHome.setSize(100, 100);
        // Choosing the location
        btnHome.setLocation(0, 0);
        // Adding the home image to the label
        btnHome.setIcon(home);        
        // Making the button listen to user
        btnHome.setActionCommand("Home");
        btnHome.addActionListener(this); // Makes this button react to action command
        // Adding the button to the JFrame
        add(btnHome);
                       
        // Calling the score giver class to get the high scores of the first player
        ScoreGiver player1 = new ScoreGiver(12);

        
        // Using SELECTION SORT to sort all the player 1 highscores in descending order
        // Looping through each element backwards starting from the second last one
        for(int i = 10; i >= 0; i--){                        
            int intTemp = p1Arr.get(i); // Storing the current element as a temporary integer
            String strTemp = nameArr[i];
            int intTemp2 = i + 1; // Storing the element after current element as another temporary integer
            // Continuing to move down(right) the list if the prior element is larger than current element
            while ((intTemp2 < p1Arr.size()) && (p1Arr.get(intTemp2) > intTemp)){
            // Swapping the element to the left with element to the right
            p1Arr.set((intTemp2 - 1), p1Arr.get(intTemp2));
            // Swapping the corresponding elements in the string array
            nameArr[intTemp2 - 1] = nameArr[intTemp2];
            // Increasing the second temporary integer so the search rightwards can continue
            intTemp2 += 1;
            }
            // After the while loop ends, setting the second last value of the second temporary integer as the initial current element
            p1Arr.set((intTemp2 - 1), intTemp);
            nameArr[intTemp2 - 1] = strTemp;
            }
        
        // Using SELECTION SORT to sort all the player 2 highscores in descending order
        // Looping through each element backwards starting from the second last one
        for(int i = 10; i >= 0; i--){                        
            int intTemp = p2Arr.get(i); // Storing the current element as a temporary integer 
            String strTemp = name2Arr[i];
            int intTemp2 = i + 1; // Storing the element after current element as another temporary integer
            // Continuing to move down(right) the list if the prior element is larger than current element
            while ((intTemp2 < p2Arr.size()) && (p2Arr.get(intTemp2) > intTemp)){
            // Swapping the element to the left with element to the right
            p2Arr.set((intTemp2 - 1), p2Arr.get(intTemp2));
            // Swapping the corresponding elements in the string array
            name2Arr[intTemp2 - 1] = name2Arr[intTemp2];
            // Increasing the second temporary integer so the search rightwards can continue
            intTemp2 += 1;
            }
            // After the while loop ends, setting the second last value of the second temporary integer as the initial current element
            p2Arr.set((intTemp2 - 1), intTemp);
            name2Arr[intTemp2 - 1] = strTemp;
            }

        // Adjusting the output variables
        for (int i = 0; i < 12; i++){
        }
        // Setting up the output strings
        strOutput1 += "P1 Top High Scores\n";
        strOutput2 += "P2 Top High Scores\n";
        for(int i = 0; i < 12; i++){
            strOutput1 += nameArr[i] + ": " + p1Arr.get(i) + "\n";
            strOutput2 += name2Arr[i] + ": " + p2Arr.get(i) + "\n";
        }    
        
        // Setting the output text areas
        // Setting up an instance of the P1 Output Text Area
        txtP1Output = new JTextArea();
        // Setting the size of the text area
        txtP1Output.setSize(500, 900);
        // Choosing the location
        txtP1Output.setLocation(10, 200);
        // Setting the text in the text area
        txtP1Output.setText(strOutput1);
        // Changing font and font size of label
        txtP1Output.setFont(new Font("Helvetica", Font.BOLD, 50));
        // Adding the text area to the JFrame
        add(txtP1Output);
        
        // Setting up an instance of the P2 Output Text Area
        txtP2Output = new JTextArea();
        // Setting the size of the text area
        txtP2Output.setSize(500, 900);
        // Choosing the location
        txtP2Output.setLocation(1420, 200);
        // Setting the text in the text area
        txtP2Output.setText(strOutput2);
        // Changing font and font size of label
        txtP2Output.setFont(new Font("Helvetica", Font.BOLD, 50));
        // Adding the text area to the JFrame
        add(txtP2Output);
    }
    public void actionPerformed (ActionEvent e){
        // Checking if Home button was clicked
        if(e.getActionCommand().equals("Home")){
            // Resetting the player name and AI name variables
            strP1Name = "";
            strP2Name = "";
            // Resetting the AI difficulties
            OpeningScreen myFrame = new OpeningScreen();
            myFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // When users clicks the close button
            // JFrame will automatically exit
            myFrame.setVisible(true); // Displaying the new JFrame
            this.dispose(); // Closing the currently open frame
       }
}
}
