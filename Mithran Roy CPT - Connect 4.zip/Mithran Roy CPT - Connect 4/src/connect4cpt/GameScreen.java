/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package connect4cpt;

import connect4cpt.PlayerScreen.returnPlayer1Name;
import connect4cpt.PlayerScreen.returnPlayer2Name;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.border.LineBorder;
import java.awt.Font;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

/**
 *
 * Author: Mithran Roy
 * Date: August 25th, 2020
 * Program which opens the main game screen of the Connect 4 Game
 */
public class GameScreen extends JFrame implements ActionListener{
    JLabel lblTitle; // This is the Title Label which shows the title image
    JLabel lblBoard; // This is the Board Label which shows the main game board
    JLabel lblP1Pic; // This is the label which shows a picture of player 1
    JLabel lblP2Pic; // This is the label which shows a picture of player 2
    JLabel lblP1Score; // This is the label which displays player 1's score
    JLabel lblP2Score; // This is the label which displays player 2's score
    JLabel lblP1Char; // This is the label which displays player 1's character name
    JLabel lblP2Char; // This is the label which displays player 2's character name
    JLabel lblTies; // This is the label which displays the number of ties
    JLabel lblP1HighScore; // This is the label which displays the p1 high score
    JLabel lblP2HighScore; // This is the label which displays the p2 high score
    JLabel lblIntro; // This is a label which gives a intro message
    JButton btnHome; // This is the button to bring up the opening screen
    JButton btnReset; // This is the button to reset the round
    JButton btnEndGame; // This is the button to end the game
    
    
    // Creating a string variable to store the name of the selected player 1
    static String strP1Name; // It is static so that it can be passed through a static method
    // Creating a string variable to store the name of the selected player 2 or AI
    static String strP2Name; // It is static so that it can be passed through a static method
    
    // Importing the images to use
    ImageIcon title = new ImageIcon("title.png");
    ImageIcon board = new ImageIcon("game.png");
    ImageIcon home = new ImageIcon("home.png");
    ImageIcon dracula = new ImageIcon("dracula.png");
    ImageIcon king = new ImageIcon("king.png");
    ImageIcon bob = new ImageIcon("man.png");
    ImageIcon ninja = new ImageIcon("ninja.png");
    ImageIcon pirate = new ImageIcon("pirate.png");
    ImageIcon joel = new ImageIcon("joel.png");
    ImageIcon ellie = new ImageIcon("ellie.png");
    ImageIcon mith = new ImageIcon("mithran.png");
    ImageIcon sarah = new ImageIcon("woman.png");
    ImageIcon chloe = new ImageIcon("girl.png");
    ImageIcon jess = new ImageIcon("calmGirl.png");
    ImageIcon mrJeg = new ImageIcon("mrJeg.png");
    ImageIcon p1 = new ImageIcon("redToken.png");
    ImageIcon p2 = new ImageIcon("yellowToken.png");
    ImageIcon p1Light = new ImageIcon ("redTransparent.png");
    ImageIcon p2Light = new ImageIcon("yellowTransparent.png");
    //ImageIcon choice = new ImageIcon("choice.png");
    
    // Creating variables to keep track of different things
    static int intP1Wins = 0; // Integer variable to keep track of how many times player X has won
    static int intP2Wins = 0; // Integer variable to keep track of how many times player O has won
    int intTies = 0; // Integer variable to keep track of how many ties there were    
    int intClicks = 0; // Integer variable to keep track of the number of intClicks to know which player's turn it is
    static int intWin = 0; // Integer variable keeping track of whether there has been a intWin and if so, who won
    boolean isPlaying = false; // Boolean variable to keep track if game is still running
    boolean isRoundOver = false; // Boolean variable to keep track of if round is over
    static boolean isEasyModeOn; // Boolean variable to keep track if AI is on easy mode
    static boolean isMedModeOn; // Boolean variable to keep track if AI is on medium mode
    boolean isPlayerR; // Boolean variable to keep track if first player is red or yellow
    //boolean canPlay = false; // Boolean tracking if the AI can play a good move
    // Declaring and initializing a 1d array to to store the seven clickable jbuttons in one step
    //JButton[] btnArr = {btnColOne, btnColTwo, btnColThree, btnColFour, btnColFive, btnColSix, btnColSeven};
    JButton[] btnArr = new JButton[7];
    int[][] intCheckArr = new int[6][7]; // 2d Array keeping track of all the spots in the grid
    int intAIMoves = 0; // An integer variable to track how many moves the AI has made
    JLabel[][] lblTokenArr = new JLabel[6][7];
    // Creating an integer to be a counter for how many times a p1 token repeats in a row
    static int intP1Counter = 0;
    // Creating an integer to be a counter for how many times a p2 or AI token repeats in a row
    static int intP2Counter = 0;
    // Creating an integer to keep track of where the high score is stored on the array list for p1
    int intP1Pos;
    // Creating an integer to keep track of where the high score is stored on the array list for p2
    int intP2Pos;
    // Creating array lists to store the high scores of the players
    static ArrayList<Integer> p1Arr = new ArrayList<Integer>();
    static ArrayList<Integer> p2Arr = new ArrayList<Integer>();
    // Creating an integer which tracks who won the game
    static int intWinTracker;
    // Creating a boolean for if AI is active
    static boolean isAIOn = false;
    // Creating a string variable to output an into message
    static String strIntro = "";
    
    public GameScreen(){
       super("Connect 4 Game Main Screen"); // This will be displayed in the Title Bar
        //Setting up the screen
        resize(1920, 1080);
        //Creating a colour to match background with RGB values
        Color gray = new Color(238, 238, 238);
        // Setting the frame layout
        setLayout(null);
        
        // Calling static class from opening screen to intCheckArr if AI mode is turned on
        OpeningScreen.returnAIMode ai = new OpeningScreen.returnAIMode();
        isAIOn = ai.getAIMode();
        
        // If AI is turned on, getting the difficulty level of the AI
        if (isAIOn){
            String strAIDifficulty = ai.getAIDif();
            // Making easy mode boolean variable true if easy mode was chosen by user
            if (strAIDifficulty.equals("Easy")){
                isEasyModeOn = true;
            } // Making medium mode on if that was chosen
            else if (strAIDifficulty.equals("Medium")){
                isMedModeOn = true;
            } // If these were not chosen, that means hard mode was chosen
        } // Program will know hard mode is on if the above two variables are false, but the isAIOn variable is true
                              
        // Setting up an instance of the Title label
        lblTitle = new JLabel();
        // Setting the size of the label
        lblTitle.setSize(760, 240);
        // Choosing the location
        lblTitle.setLocation(580, 0);
        // Adding the title image to the label
        lblTitle.setIcon(title);
        // Adding the label to the JFrame
        add(lblTitle);
        
        // Setting up an instance of the Board label
        lblBoard = new JLabel();
        // Setting the size of the label
        lblBoard.setSize(700, 600);
        // Choosing the location
        lblBoard.setLocation(610, 460);
        // Adding the board image to the label
        lblBoard.setIcon(board);
        // Adding the label to the JFrame
        add(lblBoard);
        
        // Calling static class from opening screen to get the player name
        returnPlayer1Name strName = new returnPlayer1Name();
        strP1Name = strName.getPlayer1();
        
        // Calling the score giver class to get the high scores of the first player
        ScoreGiver player1 = new ScoreGiver(12);
        // Storing the high scores of p1 in an array list
        p1Arr = player1.getList(1);       
        // Storing the high scores of p2 in an array list
        p2Arr = player1.getList(2);
                
        // Setting up an instance of the Player 1 Picture label
        lblP1Pic = new JLabel();
        // Setting the size of the label
        lblP1Pic.setSize(512, 512);
        // Choosing the location
        lblP1Pic.setLocation(50, 500);
        // Adding the player 1 image to the label depending on what the selected player is
        if (strP1Name.equals("Dracula")){
            lblP1Pic.setIcon(dracula); // Setting the icon with correct picture
            intP1Pos = 0; // Adjusting the position variable to get high score
        } else if (strP1Name.equals("King")){
            lblP1Pic.setIcon(king); // Setting the icon with correct picture
            intP1Pos = 1; // Adjusting the position variable to get high score
        } else if (strP1Name.equals("Bob")){
            lblP1Pic.setIcon(bob); // Setting the icon with correct picture
            intP1Pos = 2; // Adjusting the position variable to get high score
        } else if (strP1Name.equals("Ninja")){
            lblP1Pic.setIcon(ninja); // Setting the icon with correct picture
            intP1Pos = 3; // Adjusting the position variable to get high score
        } else if (strP1Name.equals("Pirate")){
            lblP1Pic.setIcon(pirate); // Setting the icon with correct picture
            intP1Pos = 4; // Adjusting the position variable to get high score
        } else if (strP1Name.equals("Joel")){
            lblP1Pic.setIcon(joel); // Setting the icon with correct picture
            intP1Pos = 5; // Adjusting the position variable to get high score
        } else if (strP1Name.equals("Ellie")){            
            lblP1Pic.setIcon(ellie); // Setting the icon with correct picture
            intP1Pos = 6; // Adjusting the position variable to get high score
        } else if (strP1Name.equals("Mithran")){
            lblP1Pic.setIcon(mith); // Setting the icon with correct picture
            intP1Pos = 7; // Adjusting the position variable to get high score
        } else if (strP1Name.equals("Sarah")){
            lblP1Pic.setIcon(sarah); // Setting the icon with correct picture
            intP1Pos = 8; // Adjusting the position variable to get high score
        } else if (strP1Name.equals("Chloe")){
            lblP1Pic.setIcon(chloe); // Setting the icon with correct picture
            intP1Pos = 9; // Adjusting the position variable to get high score
        } else if (strP1Name.equals("Jess")){
            lblP1Pic.setIcon(jess); // Setting the icon with correct picture
            intP1Pos = 10; // Adjusting the position variable to get high score
        } else {
            lblP1Pic.setIcon(mrJeg); // Setting the icon with correct picture
            intP1Pos = 11; // Adjusting the position variable to get high score
        }                           
        // Adding the label to the JFrame
        add(lblP1Pic);
        
        // Calling static class from opening screen to get the AI name
        returnPlayer2Name strName2 = new returnPlayer2Name();
        strP2Name = strName2.getPlayer2();
        
        // Setting up an instance of the Player 2 Picture label
        lblP2Pic = new JLabel();
        // Setting the size of the label
        lblP2Pic.setSize(512, 512);
        // Choosing the location
        lblP2Pic.setLocation(1358, 500);
        // Adding the player 1 image to the label depending on what the selected player is
        if (strP2Name.equals("Dracula")){
            lblP2Pic.setIcon(dracula); // Setting the icon with correct picture
            intP2Pos = 0; // Adjusting the position variable to get high score
        } else if (strP2Name.equals("King")){
            lblP2Pic.setIcon(king); // Setting the icon with correct picture
            intP2Pos = 1; // Adjusting the position variable to get high score
        } else if (strP2Name.equals("Bob")){
            lblP2Pic.setIcon(bob); // Setting the icon with correct picture
            intP2Pos = 2; // Adjusting the position variable to get high score
        } else if (strP2Name.equals("Ninja")){
            lblP2Pic.setIcon(ninja); // Setting the icon with correct picture
            intP2Pos = 3; // Adjusting the position variable to get high score
        } else if (strP2Name.equals("Pirate")){
            lblP2Pic.setIcon(pirate); // Setting the icon with correct picture
            intP2Pos = 4; // Adjusting the position variable to get high score
        } else if (strP2Name.equals("Joel")){
            lblP2Pic.setIcon(joel); // Setting the icon with correct picture
            intP2Pos = 5; // Adjusting the position variable to get high score
        } else if (strP2Name.equals("Ellie")){            
            lblP2Pic.setIcon(ellie); // Setting the icon with correct picture
            intP2Pos = 6; // Adjusting the position variable to get high score
        } else if (strP2Name.equals("Mithran")){
            lblP2Pic.setIcon(mith); // Setting the icon with correct picture
            intP2Pos = 7; // Adjusting the position variable to get high score
        } else if (strP2Name.equals("Sarah")){
            lblP2Pic.setIcon(sarah); // Setting the icon with correct picture
            intP2Pos = 8; // Adjusting the position variable to get high score
        } else if (strP2Name.equals("Chloe")){
            lblP2Pic.setIcon(chloe); // Setting the icon with correct picture
            intP2Pos = 9; // Adjusting the position variable to get high score
        } else if (strP2Name.equals("Jess")){
            lblP2Pic.setIcon(jess); // Setting the icon with correct picture
            intP2Pos = 10; // Adjusting the position variable to get high score
        } else {
            lblP2Pic.setIcon(mrJeg); // Setting the icon with correct picture
            intP2Pos = 11; // Adjusting the position variable to get high score
        }   
        // Adding the label to the JFrame
        add(lblP2Pic);
        
                
        // Setting up an instance of the Player 1 Score label
        lblP1Score = new JLabel();
        // Setting the size of the label
        lblP1Score.setSize(450, 60);
        // Choosing the location
        lblP1Score.setLocation(100, 300);
        // Setting the text in the Player 1 Score Label
        lblP1Score.setText("Player 1 Score: 0");
        // Changing font and font size of label
        lblP1Score.setFont(new Font("Helvetica", Font.BOLD, 50));
        // Adding the label to the JFrame
        add(lblP1Score);
        
        // Setting up an instance of the P1 High Score label
        lblP1HighScore = new JLabel();
        // Setting the size of the label
        lblP1HighScore.setSize(450, 60);
        // Choosing the location
        lblP1HighScore.setLocation(100, 230);
        // Setting the text in the P1 High Score Label
        lblP1HighScore.setText("P1 High Score as " + strP1Name + ": " + p1Arr.get(intP1Pos));
        // Changing font and font size of label
        lblP1HighScore.setFont(new Font("Helvetica", Font.BOLD, 30));
        // Adding the label to the JFrame
        add(lblP1HighScore);
        
        // Setting up an instance of the Player 1 Character Name label
        lblP1Char = new JLabel();
        // Setting the size of the label
        lblP1Char.setSize(450, 60);
        // Choosing the location
        lblP1Char.setLocation(100, 400);  
        // Setting the text in the Player 1 Character Name Label
        lblP1Char.setText("Playing as " + strP1Name);
        // Changing font and font size of label
        lblP1Char.setFont(new Font("Helvetica", Font.BOLD, 50));
        // Adding the label to the JFrame
        add(lblP1Char);
        
        // Setting up an instance of the Player 2 Score label
        lblP2Score = new JLabel();
        // Setting the size of the label
        lblP2Score.setSize(450, 60);
        // Choosing the location
        lblP2Score.setLocation(1408, 300);
        // Setting the text in the Player 2 Score Label
        if(isAIOn){
            lblP2Score.setText("AI Score: 0");
        } else{
            lblP2Score.setText("Player 2 Score: 0");
        }        
        // Changing font and font size of label
        lblP2Score.setFont(new Font("Helvetica", Font.BOLD, 50));
        // Adding the label to the JFrame
        add(lblP2Score);
        
        // Setting up an instance of the P2 High Score label
        lblP2HighScore = new JLabel();
        // Setting the size of the label
        lblP2HighScore.setSize(450, 60);
        // Choosing the location
        lblP2HighScore.setLocation(1408, 230);
        // Setting the text in the P2 High Score Label
        if(isAIOn){
            lblP2HighScore.setText("AI High Score as " + strP2Name + ": " + p2Arr.get(intP2Pos));
        } else{
            lblP2HighScore.setText("P2 High Score as " + strP2Name + ": " + p2Arr.get(intP2Pos));
        }        
        // Changing font and font size of label
        lblP2HighScore.setFont(new Font("Helvetica", Font.BOLD, 30));
        // Adding the label to the JFrame
        add(lblP2HighScore);
        
        // Setting up an instance of the Player 2 Character Name label
        lblP2Char = new JLabel();
        // Setting the size of the label
        lblP2Char.setSize(450, 60);
        // Choosing the location
        lblP2Char.setLocation(1408, 400);
        // Setting the text in the Player 2 Character Name Label
        lblP2Char.setText("Playing as " + strP2Name);        
        // Changing font and font size of label
        lblP2Char.setFont(new Font("Helvetica", Font.BOLD, 50));
        // Adding the label to the JFrame
        add(lblP2Char);        
        
        // Setting up an instance of the Ties label
        lblTies = new JLabel();
        // Setting the size of the label
        lblTies.setSize(200, 60);
        // Choosing the location
        lblTies.setLocation(150, 0);
        // Setting the text in the Ties Label
        lblTies.setText("Ties: 0");        
        // Changing font and font size of label
        lblTies.setFont(new Font("Helvetica", Font.BOLD, 50));
        // Adding the label to the JFrame
        add(lblTies);
        
        // Setting up an instance of the Intro label
        lblIntro = new JLabel();
        // Setting the size of the label
        lblIntro.setSize(400, 60);
        // Choosing the location
        lblIntro.setLocation(150, 100);
        // Calling a recursive method to update the strIntro variable
        flip(123);
        // Setting the text in the Intro Label
        lblIntro.setText(strIntro + " Start!");        
        // Changing font and font size of label
        lblIntro.setFont(new Font("Helvetica", Font.BOLD, 50));
        // Adding the label to the JFrame
        add(lblIntro);
        
        // Setting up an instance of the Home Button
        btnHome = new JButton();
        // Setting up the size of the button
        btnHome.setSize(100, 100);
        // Choosing the location
        btnHome.setLocation(0, 0);
        // Adding the home image to the label
        btnHome.setIcon(home);        
        // Making the button listen to user
        btnHome.setActionCommand("Home");
        btnHome.addActionListener(this); // Makes this button react to action command
        // Adding the button to the JFrame
        add(btnHome);
        
        // Setting up an instance of the Reset Round Button
        btnReset = new JButton();
        // Setting up the size of the button
        btnReset.setSize(400, 100);
        // Choosing the location
        btnReset.setLocation(1520, 0);
        // Setting the text of the button
        btnReset.setText("Reset Round");
        // Setting the font and size of the text
        btnReset.setFont(new Font("Garamond", Font.BOLD, 60));
        // Changing the background colour of the button
        btnReset.setBackground(Color.white);
        btnReset.setOpaque(true);
        // Making the button listen to user
        btnReset.setActionCommand("Reset");
        btnReset.addActionListener(this); // Makes this button react to action command
        // Adding the button to the JFrame
        add(btnReset);
        
        // Setting up an instance of the End Game Button
        btnEndGame = new JButton();
        // Setting up the size of the button
        btnEndGame.setSize(400, 100);
        // Choosing the location
        btnEndGame.setLocation(1520, 100);
        // Setting the text of the button
        btnEndGame.setText("End Game");
        // Setting the font and size of the text
        btnEndGame.setFont(new Font("Garamond", Font.BOLD, 60));
        // Changing the background colour of the button
        btnEndGame.setBackground(Color.white);
        btnEndGame.setOpaque(true);
        // Making the button listen to user
        btnEndGame.setActionCommand("End");
        btnEndGame.addActionListener(this); // Makes this button react to action command
        // Adding the button to the JFrame
        add(btnEndGame);
                
        // Telling user to choose the game mode
            String[] strOptions = {"Yellow", "Red"}; // Array of options
            ImageIcon icon = new ImageIcon("choice.png");
            String strQuestion;
            // Phrasing the question slightly differently depending on if player is playing with AI
            if(isAIOn){
                strQuestion = "Would you like to play as Red or Yellow?";
            } else {
                strQuestion = "Would you Player 1 like to play as Red or Yellow?";
            }
            String strDecision = (String)JOptionPane.showInputDialog(null, strQuestion,
                    "Colour Selection", JOptionPane.QUESTION_MESSAGE, icon, strOptions, strOptions[1]);
            
            if (strDecision.equals("Red")){
                   //gui.txtMsg.setText("Player X's Turn");
                   isPlayerR = true;
               }
            else {
                   //gui.txtMsg.setText("Player O's Turn");
                   isPlayerR = false;
                   // Swapping the red and yellow token images
                   p1 = new ImageIcon("yellowToken.png");
                   p1Light = new ImageIcon("yellowTransparent.png");
                   p2 = new ImageIcon("redToken.png");
                   p2Light = new ImageIcon("redTransparent.png");
               }
        // Setting up all the buttons to drop a token
        for (int i = 0; i < btnArr.length; i++){
            // Creating an instance of the button
            btnArr[i] = new JButton();
            // Setting up the size of the button
            btnArr[i].setSize(80, 220);
            // Choosing the location
            btnArr[i].setLocation(i + 620 + 100 * i, 240);
            // Adding the home p1 light image to the label
            btnArr[i].setIcon(p1Light);
            // Removing the border so the game looks nicer
            btnArr[i].setBorder(new LineBorder(gray));
            // Making the button listen to user
            btnArr[i].setActionCommand(Integer.toString(i+1));
            btnArr[i].addActionListener(this); // Makes this button react to action command
            // Adding the button to the JFrame
            add(btnArr[i]);
        }
        
        // Setting up all the JLabels in the bottom column
        for (int row = 0; row < 6; row++){
            for (int col = 0; col < 7; col++){
            // Creating an instance of the label
            lblTokenArr [row][col] = new JLabel();
            // Setting up the size of the label
            lblTokenArr[row][col].setSize(80, 80);
            // Choosing the location
            // Adjusting for minor discrepancies in the board image
            if (col < 3){
                if (row < 3){
                   lblTokenArr[row][col].setLocation(621 + 100 * col, 476 + row * 100 - 2 - row); 
                } else if (row < 4){
                   lblTokenArr[row][col].setLocation(621 + 100 * col, 476 + row * 100 - 3 - row);
                } else if (row < 5){
                   lblTokenArr[row][col].setLocation(621 + 100 * col, 476 + row * 100 - 4 - row);
                } else{
                   lblTokenArr[row][col].setLocation(621 + 100 * col, 476 + row * 100 - 5 - row); 
                }               
            } else if (col < 6){
                if (row < 3){
                   lblTokenArr[row][col].setLocation(620 + 100 * col, 476 + row * 100 - 2 - row); 
                } else if (row < 4){
                   lblTokenArr[row][col].setLocation(620 + 100 * col, 476 + row * 100 - 3 - row);
                } else if (row < 5){
                   lblTokenArr[row][col].setLocation(620 + 100 * col, 476 + row * 100 - 4 - row);
                } else{
                   lblTokenArr[row][col].setLocation(620 + 100 * col, 476 + row * 100 - 5 - row); 
                }   
            } else {
                if (row < 3){
                   lblTokenArr[row][col].setLocation(619 + 100 * col, 476 + row * 100 - 2 - row); 
                } else if (row < 4){
                   lblTokenArr[row][col].setLocation(619 + 100 * col, 476 + row * 100 - 3 - row);
                } else if (row < 5){
                   lblTokenArr[row][col].setLocation(619 + 100 * col, 476 + row * 100 - 4 - row);
                } else{
                   lblTokenArr[row][col].setLocation(619 + 100 * col, 476 + row * 100 - 5 - row); 
                }            
            }            
            // Adding the token image
            //lblTokenArr[row][col].setIcon(p1);
            // Adding the label to the JFrame
            add(lblTokenArr[row][col]);
        }
        }
        
        
        // Making all the spots in the 2d intCheckArr array 0
        for (int row = 0; row <= 3; row++){
           for (int col = 0; col <= 3; col++){
               intCheckArr[row][col] = 0;
           }
       }
    }
    
    public void actionPerformed (ActionEvent e){
        // Checking if Home button was clicked
        if(e.getActionCommand().equals("Home")){
            // Saving the high score
            save();
            // Resetting the board
            reset();
            // Resetting the player name and AI name variables
            strP1Name = "";
            strP2Name = "";
            // Resetting the AI difficulties
            OpeningScreen myFrame = new OpeningScreen();
            myFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // When users clicks the close button
            // JFrame will automatically exit
            myFrame.setVisible(true); // Displaying the new JFrame
            this.dispose(); // Closing the currently open frame
       }
       // Checking if the reset round button was clicked
       if(e.getActionCommand().equals("Reset")){
           // Calling the method to reset the round
           reset();
       }
       if(e.getActionCommand().equals("End")){
            // Saving the high score
            save();
            // Resetting board
            reset();
            //Setting the boolean variable which tracks who won
            if(intP1Wins > intP2Wins){
                intWinTracker = 1;
            } else if (intP2Wins > intP1Wins){
                intWinTracker = 2;
            } else {
                intWinTracker = 3;
            }
            // Resetting the player name and AI name variables
            strP1Name = "";
            strP2Name = "";
            // Resetting the AI difficulties
            GameOverScreen myFrame = new GameOverScreen();
            myFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // When users clicks the close button
            // JFrame will automatically exit
            myFrame.setVisible(true); // Displaying the new JFrame
            this.dispose(); // Closing the currently open frame
       }
       // Checking if first column button was clicked
       if (e.getActionCommand().equals("1")){
           b1();
       }
       // Checking if second column button was clicked
       if (e.getActionCommand().equals("2")){
           b2();
       }
       // Checking if third column button was clicked
       if (e.getActionCommand().equals("3")){
           b3();
       }
       // Checking if fourth column button was clicked
       if (e.getActionCommand().equals("4")){
           b4();
       }
       // Checking if fifth column button was clicked
       if(e.getActionCommand().equals("5")){
           b5();
       }
       // Checking if sixth column button was clicked
       if(e.getActionCommand().equals("6")){
           b6();
       }
       // Checking if seventh column button was clicked
       if(e.getActionCommand().equals("7")){
           b7();
       }
    }
    
    // Creating a method which decides how to place token in first column
    void b1(){
        // Only allowing the move if the no one has won yet
        if(intWin == 0){
            // Only allowing click if the column is not full
            if(intCheckArr[0][0] == 0){
                // Increasing the integer variable storing the number of intClicks
                intClicks += 1;
                boolean isDone = false; // Local boolean variable keeping track if move has been made or not
                // Placing the token in the first available spot in column starting from bottom, if possible
                for(int i = 5; i >= 0; i--){
                    if(intCheckArr[i][0] == 0 && isDone == false){
                        // Modifying variables according to whose turn it is
                        if ((intClicks % 2) == 1){ // This means it was player one's move
                            intCheckArr[i][0] = 1; // Storing 1 to keep track that p1 has token here
                            lblTokenArr[i][0].setIcon(p1);
                        } else { // This means it was p2 or AI's turn
                            intCheckArr[i][0] = 2; // Storing 2 to keep track that p2 has token here
                            lblTokenArr[i][0].setIcon(p2);  
                        }

                        //lblToken.setLocation(621, 965);
                        isDone = true;
                    }
                }
                // Checking if anyone won with winner method
                winner();
            } else{
                JOptionPane.showMessageDialog(null, "Column 1 is full. Please select another column.");
            }            
        } else{
            JOptionPane.showMessageDialog(null, "Round is over, please select \"Reset Round\" to start a new round or the Home button to start a new game");
        }
    }
           
    
    // Creating a method which decides how to place token in second column
    void b2(){
        // Only allowing the move if the no one has won yet
        if(intWin == 0){
            // Only allowing click if the column is not full
            if(intCheckArr[0][1] == 0){
                // Increasing the integer variable storing the number of intClicks
                intClicks += 1;
                boolean isDone = false; // Local boolean variable keeping track if move has been made or not
                // Placing the token in the first available spot in column starting from bottom, if possible
                for(int i = 5; i >= 0; i--){
                    if(intCheckArr[i][1] == 0 && isDone == false){
                        // Modifying variables according to whose turn it is
                        if ((intClicks % 2) == 1){ // This means it was player one's move
                            intCheckArr[i][1] = 1; // Storing 1 to keep track that p1 has token here
                            lblTokenArr[i][1].setIcon(p1);
                        } else { // This means it was p2 or AI's turn
                            intCheckArr[i][1] = 2; // Storing 2 to keep track that p2 has token here
                            lblTokenArr[i][1].setIcon(p2);  
                        }

                        //lblToken.setLocation(621, 965);
                        isDone = true;
                    }
                }
                // Checking if anyone won with winner method
                winner();
            } else{
                JOptionPane.showMessageDialog(null, "Column 2 is full. Please select another column.");
            }            
        } else{
            JOptionPane.showMessageDialog(null, "Round is over, please select \"Reset Round\" to start a new round or the Home button to start a new game");
        }        
    }
    
    // Creating a method which decides how to place token in third column
    void b3(){
        // Only allowing the move if the no one has won yet
        if(intWin == 0){
            // Only allowing click if the column is not full
            if(intCheckArr[0][2] == 0){
                // Increasing the integer variable storing the number of intClicks
                intClicks += 1;
                boolean isDone = false; // Local boolean variable keeping track if move has been made or not
                // Placing the token in the first available spot in column starting from bottom, if possible
                for(int i = 5; i >= 0; i--){
                    if(intCheckArr[i][2] == 0 && isDone == false){
                        // Modifying variables according to whose turn it is
                        if ((intClicks % 2) == 1){ // This means it was player one's move
                            intCheckArr[i][2] = 1; // Storing 1 to keep track that p1 has token here
                            lblTokenArr[i][2].setIcon(p1);
                        } else { // This means it was p2 or AI's turn
                            intCheckArr[i][2] = 2; // Storing 2 to keep track that p2 has token here
                            lblTokenArr[i][2].setIcon(p2);  
                        }

                        //lblToken.setLocation(621, 965);
                        isDone = true;
                    }
                }       
                // Checking if anyone won with winner method
                winner();
            } else {
                JOptionPane.showMessageDialog(null, "Column 3 is full. Please select another column.");
            }            
        } else{
            JOptionPane.showMessageDialog(null, "Round is over, please select \"Reset Round\" to start a new round or the Home button to start a new game");
        }
    }
    
    // Creating a method which decides how to place token in fourth column
    void b4(){
        // Only allowing the move if the no one has won yet
        if(intWin == 0){
            // Only allowing click if the column is not full
            if(intCheckArr[0][3] == 0){
                // Increasing the integer variable storing the number of intClicks
                intClicks += 1;
                boolean isDone = false; // Local boolean variable keeping track if move has been made or not
                // Placing the token in the first available spot in column starting from bottom, if possible
                for(int i = 5; i >= 0; i--){
                    if(intCheckArr[i][3] == 0 && isDone == false){
                        // Modifying variables according to whose turn it is
                        if ((intClicks % 2) == 1){ // This means it was player one's move
                            intCheckArr[i][3] = 1; // Storing 1 to keep track that p1 has token here
                            lblTokenArr[i][3].setIcon(p1);
                        } else { // This means it was p2 or AI's turn
                            intCheckArr[i][3] = 2; // Storing 2 to keep track that p2 has token here
                            lblTokenArr[i][3].setIcon(p2);  
                        }

                        //lblToken.setLocation(621, 965);
                        isDone = true;
                    }
                }
                // Checking if anyone won with winner method
                winner();
            } else{
                JOptionPane.showMessageDialog(null, "Column 4 is full. Please select another column.");
            }            
        } else{
            JOptionPane.showMessageDialog(null, "Round is over, please select \"Reset Round\" to start a new round or the Home button to start a new game");
        }                
    }
    
    // Creating a method which decides how to place token in fifth column
    void b5(){
        // Only allowing the move if the no one has won yet
        if(intWin == 0){
            // Only allowing click if the column is not full
            if(intCheckArr[0][4] == 0){
                // Increasing the integer variable storing the number of intClicks
                intClicks += 1;
                boolean isDone = false; // Local boolean variable keeping track if move has been made or not
                // Placing the token in the first available spot in column starting from bottom, if possible
                for(int i = 5; i >= 0; i--){
                    if(intCheckArr[i][4] == 0 && isDone == false){
                        // Modifying variables according to whose turn it is
                        if ((intClicks % 2) == 1){ // This means it was player one's move
                            intCheckArr[i][4] = 1; // Storing 1 to keep track that p1 has token here
                            lblTokenArr[i][4].setIcon(p1);
                        } else { // This means it was p2 or AI's turn
                            intCheckArr[i][4] = 2; // Storing 2 to keep track that p2 has token here
                            lblTokenArr[i][4].setIcon(p2);  
                        }

                        //lblToken.setLocation(621, 965);
                        isDone = true;
                    }
                } 
                // Checking if anyone won with winner method
                winner();
            } else {
                JOptionPane.showMessageDialog(null, "Column 5 is full. Please select another column.");
            }            
        } else{
            JOptionPane.showMessageDialog(null, "Round is over, please select \"Reset Round\" to start a new round or the Home button to start a new game");
        }        
    }
    
    // Creating a method which decides how to place token in sixth column
    void b6(){
        // Only allowing the move if the no one has won yet
        if(intWin == 0){
            // Only allowing click if the column is not full
            if(intCheckArr[0][5] == 0){
                // Increasing the integer variable storing the number of intClicks
                intClicks += 1;
                boolean isDone = false; // Local boolean variable keeping track if move has been made or not
                // Placing the token in the first available spot in column starting from bottom, if possible
                for(int i = 5; i >= 0; i--){
                    if(intCheckArr[i][5] == 0 && isDone == false){
                        // Modifying variables according to whose turn it is
                        if ((intClicks % 2) == 1){ // This means it was player one's move
                            intCheckArr[i][5] = 1; // Storing 1 to keep track that p1 has token here
                            lblTokenArr[i][5].setIcon(p1);
                        } else { // This means it was p2 or AI's turn
                            intCheckArr[i][5] = 2; // Storing 2 to keep track that p2 has token here
                            lblTokenArr[i][5].setIcon(p2);  
                        }

                        //lblToken.setLocation(621, 965);
                        isDone = true;
                    }
                }  
                // Checking if anyone won with winner method
                winner();
            } else{
                JOptionPane.showMessageDialog(null, "Column 6 is full. Please select another column.");
            }            
        } else{
            JOptionPane.showMessageDialog(null, "Round is over, please select \"Reset Round\" to start a new round or the Home button to start a new game");
        }        
    }
    
    // Creating a method which decides how to place token in seventh column
    void b7(){
        // Only allowing the move if the no one has won yet
        if(intWin == 0){
            // Only allowing click if the column is not full
            if(intCheckArr[0][6] == 0){
                // Increasing the integer variable storing the number of intClicks
            intClicks += 1;
            boolean isDone = false; // Local boolean variable keeping track if move has been made or not
            // Placing the token in the first available spot in column starting from bottom, if possible
            for(int i = 5; i >= 0; i--){
                if(intCheckArr[i][6] == 0 && isDone == false){
                    // Modifying variables according to whose turn it is
                    if ((intClicks % 2) == 1){ // This means it was player one's move
                        intCheckArr[i][6] = 1; // Storing 1 to keep track that p1 has token here
                        lblTokenArr[i][6].setIcon(p1);
                    } else { // This means it was p2 or AI's turn
                        intCheckArr[i][6] = 2; // Storing 2 to keep track that p2 has token here
                        lblTokenArr[i][6].setIcon(p2);  
                    }

                    //lblToken.setLocation(621, 965);
                    isDone = true;
                }
            }     
            // Checking if anyone won with winner method
            winner();
            } else{
                JOptionPane.showMessageDialog(null, "Column 7 is full. Please select another column.");
            }            
        } else{
            JOptionPane.showMessageDialog(null, "Round is over, please select \"Reset Round\" to start a new round or the Home button to start a new game");
        }        
    }
    
    // Method which checks if there is a winner
    void winner(){
        // First checking if there is any four repeats in a row        
        for (int row = 0; row < 6; row++){
            if (intWin == 0){ // Only proceeding if no one has won yet
                for (int col = 0; col < 6; col++){
                    // Checking if there are multiple p1 tokens in current row
                    if(intCheckArr[row][col] == 1 && intCheckArr[row][col + 1] == 1){
                        intP1Counter += 1;
                    // If there is not two in a row, resetting the counter
                    } else {
                        // Make sure that it is only reset if there isn't four in a side by side
                        if (intP1Counter < 3){                            
                        intP1Counter = 0;
                        }
                    }
                    // Checking if there are multiple p2 tokens in current row
                    if (intCheckArr[row][col] == 2 && intCheckArr[row][col + 1] == 2){
                        intP2Counter += 1;
                    // If there is not two in a row, resetting the counter
                    } else {
                        // Make sure that it is only reset if there isn't four in a side by side
                        if (intP2Counter < 3){                            
                            intP2Counter = 0;
                        }   
                    }      
                }
                // Checking if anyone won
                sideBySide(intP1Counter, intP2Counter);
                
            }     
                
        }
        
        // Now checking if there is any four repeats in a column
        for (int c = 0; c < 7; c++){
            // Only proceeding if no one has won yet
            if (intWin == 0){
                for (int r = 0; r < 5; r++){
                    // Checking if there are multiple p1 tokens in current column
                    if(intCheckArr[r][c] == 1 && intCheckArr[r + 1][c] == 1){
                        intP1Counter += 1;
                    // If there is not two in a row, resetting the counter
                    } else {
                        // Make sure that it is only reset if there isn't four in a side by side
                        if (intP1Counter < 3){
                            intP1Counter = 0;
                        }                         
                    }
                    // Checking if there are multiple p2 tokens in current column
                    if (intCheckArr[r][c] == 2 && intCheckArr[r + 1][c] == 2){
                        intP2Counter += 1;
                    // If there is not two in a row, resetting the counter
                    } else {
                        // Make sure that it is only reset if there isn't four in a side by side
                        if (intP2Counter < 3){
                            intP2Counter = 0;
                        }                         
                    }
                }
                // Checking if anyone won
                sideBySide(intP1Counter, intP2Counter);

            }                 
                
        }   
           
        // First checking the diagonal that goes from [0][3] to [3][6]
        for (int r = 0; r < 3; r++){
            // Only proceeding if no one has won yet
            if (intWin == 0){
                for (int c = 3; c < 6; c++){
                    // Only checking the c and r values correspond with right element
                    if ((r == 0 && c == 3) || (r == 1 && c == 4) || (r == 2 && c == 5)){ 
                    // Checking if there are multiple p1 tokens in current diagonal
                        if(intCheckArr[r][c] == 1 && intCheckArr[r + 1][c + 1] == 1){
                            intP1Counter += 1;
                        // Checking if there are multiple p2 tokens in current column
                        } else if(intCheckArr[r][c] == 2 && intCheckArr[r + 1][c + 1] == 2){
                            intP2Counter += 1;
                        }                        
                    }                
                }                               
            }            
        }
        // Checking if anyone won
        sideBySide(intP1Counter, intP2Counter);
        
        
        
        // Now checking the diagonal that goes from [0][3] to [3][0]
        for (int r = 0; r < 3; r++){
            // Only proceeding if no one has won yet
            if (intWin == 0){
                for (int c = 3; c > 0; c--){
                    // Only checking the c and r values correspond with right element
                    if ((r == 0 && c == 3) || (r == 1 && c == 2) || (r == 2 && c == 1)){ 
                    // Checking if there are multiple p1 tokens in current diagonal
                        if(intCheckArr[r][c] == 1 && intCheckArr[r + 1][c - 1] == 1){
                            intP1Counter += 1;
                        // Checking if there are multiple p2 tokens in current column
                        } else if(intCheckArr[r][c] == 2 && intCheckArr[r + 1][c - 1] == 2){
                            intP2Counter += 1;
                        }
                    }                
                }               
            }            
        }
        // Checking if anyone won
        sideBySide(intP1Counter, intP2Counter);
                
        // Now checking the diagonal that goes from [2][0] to [5][3]
        for (int r = 2; r < 5; r++){
            // Only proceeding if no one has won yet
            if (intWin == 0){
                for (int c = 0; c < 3; c++){
                    // Only checking the c and r values correspond with right element
                    if ((r == 2 && c == 0) || (r == 3 && c == 1) || (r == 4 && c == 2)){ 
                    // Checking if there are multiple p1 tokens in current diagonal
                        if(intCheckArr[r][c] == 1 && intCheckArr[r + 1][c + 1] == 1){
                            intP1Counter += 1;
                        // Checking if there are multiple p2 tokens in current column
                        } else if(intCheckArr[r][c] == 2 && intCheckArr[r + 1][c + 1] == 2){
                            intP2Counter += 1;
                        }
                    }                
                }               
            }            
        }
        // Checking if anyone won
        sideBySide(intP1Counter, intP2Counter);
        
        // Now checking the diagonal that goes from [2][6] to [5][3]
        for (int r = 2; r < 5; r++){
            // Only proceeding if no one has won yet
            if (intWin == 0){
                for (int c = 6; c > 3; c--){
                    // Only checking the c and r values correspond with right element
                    if ((r == 2 && c == 6) || (r == 3 && c == 5) || (r == 4 && c == 4)){ 
                    // Checking if there are multiple p1 tokens in current diagonal
                        if(intCheckArr[r][c] == 1 && intCheckArr[r + 1][c - 1] == 1){
                            intP1Counter += 1;
                        // Checking if there are multiple p2 tokens in current column
                        } else if(intCheckArr[r][c] == 2 && intCheckArr[r + 1][c - 1] == 2){
                            intP2Counter += 1;
                        }
                    }                
                }               
            }            
        }
        // Checking if anyone won
        sideBySide(intP1Counter, intP2Counter);
        
        // Now checking the diagonal that goes from [1][0] to [5][4]        
        for (int r = 1; r < 5; r++){
            // Only proceeding if no one has won yet
            if (intWin == 0){
                for (int c = 0; c < 4; c++){
                    // Only checking the c and r values correspond with right element
                    if ((r == 1 && c == 0) || (r == 2 && c == 1) || (r == 3 && c == 2) || (r == 4 && c == 3)){ 
                    // Checking if there are multiple p1 tokens in current diagonal
                        if(intCheckArr[r][c] == 1 && intCheckArr[r + 1][c + 1] == 1){
                            intP1Counter += 1;
                        // Checking if there are multiple p2 tokens in current column
                        } else if(intCheckArr[r][c] == 2 && intCheckArr[r + 1][c + 1] == 2){
                            intP2Counter += 1;
                        }
                    }                
                }               
            }            
        }
        // Checking if anyone won
        sideBySide(intP1Counter, intP2Counter);
        
        // Now checking the diagonal that goes from [0][2] to [4][6]        
        for (int r = 0; r < 4; r++){
            // Only proceeding if no one has won yet
            if (intWin == 0){
                for (int c = 2; c < 6; c++){
                    // Only checking the c and r values correspond with right element
                    if ((r == 0 && c == 2) || (r == 1 && c == 3) || (r == 2 && c == 4) || (r == 3 && c == 5)){ 
                    // Checking if there are multiple p1 tokens in current diagonal
                        if(intCheckArr[r][c] == 1 && intCheckArr[r + 1][c + 1] == 1){
                            intP1Counter += 1;
                        // Checking if there are multiple p2 tokens in current column
                        } else if(intCheckArr[r][c] == 2 && intCheckArr[r + 1][c + 1] == 2){
                            intP2Counter += 1;
                        }
                    }                
                }               
            }            
        }
        // Checking if anyone won
        sideBySide(intP1Counter, intP2Counter);
        
        // Now checking the diagonal that goes from [0][1] to [5][6]        
        for (int r = 0; r < 5; r++){
            // Only proceeding if no one has won yet
            if (intWin == 0){
                for (int c = 1; c < 6; c++){
                    // Only checking the c and r values correspond with right element
                    if ((r == 0 && c == 1) || (r == 1 && c == 2) || (r == 2 && c == 3) || (r == 3 && c == 4) || (r == 4 && c == 5)){ 
                    // Checking if there are multiple p1 tokens in current diagonal
                        if(intCheckArr[r][c] == 1 && intCheckArr[r + 1][c + 1] == 1){
                            intP1Counter += 1;
                        // Resetting counter if there are not two side by side
                        } else {
                            // Make sure that it is only reset if there isn't four in a side by side
                            if (intP1Counter < 3){                            
                            intP1Counter = 0;                        
                            }
                        }
                        // Checking if there are multiple p2 tokens in current column
                        if(intCheckArr[r][c] == 2 && intCheckArr[r + 1][c + 1] == 2){
                            intP2Counter += 1;
                        // Resetting counter if there are not two side by side
                        } else {
                            // Make sure that it is only reset if there isn't four in a side by side
                            if (intP2Counter < 3){                            
                            intP2Counter = 0;                        
                            }
                        }
                    }                
                }               
            }            
        }
        // Checking if anyone won
        sideBySide(intP1Counter, intP2Counter);
        
        // Now checking the diagonal that goes from [0][0] to [5][5]        
        for (int r = 0; r < 5; r++){
            // Only proceeding if no one has won yet
            if (intWin == 0){
                for (int c = 0; c < 5; c++){
                    // Only checking the c and r values correspond with right element
                    if ((r == 0 && c == 0) || (r == 1 && c == 1) || (r == 2 && c == 2) || (r == 3 && c == 3) || (r == 4 && c == 4)){ 
                    // Checking if there are multiple p1 tokens in current diagonal
                        if(intCheckArr[r][c] == 1 && intCheckArr[r + 1][c + 1] == 1){
                            intP1Counter += 1;
                        // Resetting counter if there are not two side by side
                        } else {
                            // Make sure that it is only reset if there isn't four in a side by side
                            if (intP1Counter < 3){                            
                            intP1Counter = 0;                        
                            }
                        }
                        // Checking if there are multiple p2 tokens in current column
                        if(intCheckArr[r][c] == 2 && intCheckArr[r + 1][c + 1] == 2){
                            intP2Counter += 1;
                        // Resetting counter if there are not two side by side
                        } else {
                            // Make sure that it is only reset if there isn't four in a side by side
                            if (intP2Counter < 3){                            
                            intP2Counter = 0;                        
                            }
                        }
                    }                
                }               
            }            
        }
        // Checking if anyone won
        sideBySide(intP1Counter, intP2Counter);
               
        // Now checking the diagonal that goes from [0][4] to [4][0]
        for (int r = 0; r < 4; r++){
            // Only proceeding if no one has won yet
            if (intWin == 0){
                for (int c = 4; c > 0; c--){
                    // Only checking the c and r values correspond with right element
                    if ((r == 0 && c == 4) || (r == 1 && c == 3) || (r == 2 && c == 2) || (r == 3 && c == 1)){ 
                    // Checking if there are multiple p1 tokens in current diagonal
                        if(intCheckArr[r][c] == 1 && intCheckArr[r + 1][c - 1] == 1){
                            intP1Counter += 1;
                        // Checking if there are multiple p2 tokens in current column
                        } else if(intCheckArr[r][c] == 2 && intCheckArr[r + 1][c - 1] == 2){
                            intP2Counter += 1;
                        }
                    }                
                }               
            }            
        }
        // Checking if anyone won
        sideBySide(intP1Counter, intP2Counter);
        
        // Now checking the diagonal that goes from [0][5] to [5][0]
        for (int r = 0; r < 5; r++){
            // Only proceeding if no one has won yet
            if (intWin == 0){
                for (int c = 5; c > 0; c--){
                    // Only checking the c and r values correspond with right element
                    if ((r == 0 && c == 5) || (r == 1 && c == 4) || (r == 2 && c == 3) || (r == 3 && c == 2) || (r == 4 && c == 1)){ 
                    // Checking if there are multiple p1 tokens in current diagonal
                        if(intCheckArr[r][c] == 1 && intCheckArr[r + 1][c - 1] == 1){
                            intP1Counter += 1;                        
                        // Resetting counter if there are not two side by side
                        } else {
                            // Make sure that it is only reset if there isn't four in a side by side
                            if (intP1Counter < 3){                            
                            intP1Counter = 0;                        
                            }
                        }
                        // Checking if there are multiple p2 tokens in current column
                        if(intCheckArr[r][c] == 2 && intCheckArr[r + 1][c - 1] == 2){
                            intP2Counter += 1;
                        // Resetting counter if there are not two side by side
                        } else {
                            // Make sure that it is only reset if there isn't four in a side by side
                            if (intP2Counter < 3){                            
                            intP2Counter = 0;                        
                            }
                        }
                    }                
                }               
            }            
        }
        // Checking if anyone won
        sideBySide(intP1Counter, intP2Counter);
        
        // Now checking the diagonal that goes from [0][6] to [5][1]
        for (int r = 0; r < 5; r++){
            // Only proceeding if no one has won yet
            if (intWin == 0){
                for (int c = 6; c > 1; c--){
                    // Only checking the c and r values correspond with right element
                    if ((r == 0 && c == 6) || (r == 1 && c == 5) || (r == 2 && c == 4) || (r == 3 && c == 3) || (r == 4 && c == 2)){ 
                    // Checking if there are multiple p1 tokens in current diagonal
                        if(intCheckArr[r][c] == 1 && intCheckArr[r + 1][c - 1] == 1){
                            intP1Counter += 1;                        
                        // Resetting counter if there are not two side by side
                        } else {
                            // Make sure that it is only reset if there isn't four in a side by side
                            if (intP1Counter < 3){                            
                            intP1Counter = 0;                        
                            }
                        }
                        // Checking if there are multiple p2 tokens in current column
                        if(intCheckArr[r][c] == 2 && intCheckArr[r + 1][c - 1] == 2){
                            intP2Counter += 1;
                        // Resetting counter if there are not two side by side
                        } else {
                            // Make sure that it is only reset if there isn't four in a side by side
                            if (intP2Counter < 3){                            
                            intP2Counter = 0;                        
                            }
                        }
                    }                
                }               
            }            
        }
        // Checking if anyone won
        sideBySide(intP1Counter, intP2Counter);
        
        // Now checking the diagonal that goes from [1][6] to [5][2]
        for (int r = 1; r < 5; r++){
            // Only proceeding if no one has won yet
            if (intWin == 0){
                for (int c = 6; c > 2; c--){
                    // Only checking the c and r values correspond with right element
                    if ((r == 1 && c == 6) || (r == 2 && c == 5) || (r == 3 && c == 4) || (r == 4 && c == 3)){ 
                    // Checking if there are multiple p1 tokens in current diagonal
                        if(intCheckArr[r][c] == 1 && intCheckArr[r + 1][c - 1] == 1){
                            intP1Counter += 1;
                        // Checking if there are multiple p2 tokens in current column
                        } else if(intCheckArr[r][c] == 2 && intCheckArr[r + 1][c - 1] == 2){
                            intP2Counter += 1;
                        }
                    }                
                }               
            }            
        }
        // Checking if anyone won
        sideBySide(intP1Counter, intP2Counter);
        
        // Updating the colour of the slightly transparent tokens after each click
        // Setting up all the buttons to drop a token
        for (int i = 0; i < btnArr.length; i++){
            if (intClicks % 2 == 1){ // If it is player 1's turn
                btnArr[i].setIcon(p2Light); // Setting the button colours to chosen colour
            } else { // If it is player 2 or AI's turn
                btnArr[i].setIcon(p1Light); // Setting the button colours to unchosen colour               
            }
        }
        
        // Declaring it a tie if there are 42 intClicks and no one has won
        if(intClicks == 42 && intWin == 0){
            JOptionPane.showMessageDialog(null, "It's a tie!");
            intTies += 1;
            intWin = 1;
        }
        
        // Resetting the intro label
        lblIntro.setText("");
        
        // Updating all the scorekeeping labels
        lblP1Score.setText("Player 1 Score: " + intP1Wins);
        if (isAIOn){
            lblP2Score.setText("AI Score: " + intP2Wins);
        } else{
            lblP2Score.setText("Player 2 Score: " + intP2Wins);
        }        
        lblTies.setText("Ties: " + intTies);
        // Automating a responding move if AI is playing and player has not won yet
        if((isAIOn) && (intWin == 0) && (intClicks % 2 == 1)){
            //if(isEasyModeOn){
                easyAI();
            //}
        }
    }
    
    // Method which checks if there are four side by side
    // The parameter are to take in the variables tracking how many tokens are side by side
    public static void sideBySide(int intP1, int intP2){
        // If there are atleast 4 p1 tokens in the row, declaring p1 as the winner
        if (intP1 >= 3){
            intP1Wins += 1; // Increasing variable storing p1 wins
            intWin = 1; // Making variable tracking if anyone won to 1
            JOptionPane.showMessageDialog(null, "Player 1 wins this round!");
        // If there are 4 p2 tokens in the row, declaring p2 or AI as the winner
        } else if (intP2 >= 3){
            intP2Wins += 1; // Increasing variable storing p2 and AI wins
            JOptionPane.showMessageDialog(null, "Player 2 wins this round!");
            intWin = 1; // Making variable tracking if anyone won to 1
        }
        // Resetting the counter variables
        intP1Counter = 0;
        intP2Counter = 0;
        
        // Making a hard AI move if it is on
        if(isAIOn){
            if(isEasyModeOn == false && isMedModeOn == false){
                
            }
        }
    }
    
    // Method which makes the Easy AI move
    void easyAI(){        
        // The easy AI randomly places a token
        // Creating a random integer variable from 1 to 7 to determine AI's move
        int intRandom = 0;
        
            while ((intRandom < 1) || (intRandom > 7)){
                intRandom = (int)Math.round(Math.random() * 10);               
        }
        
        // The AI will attempt to place a token in the column matching the chosen number
        if(intRandom == 1){
            // Only allowing click if the column is not full
            if(intCheckArr[0][0] == 0){
                // Increasing the integer variable storing the number of intClicks
                intClicks += 1;
                boolean isDone = false; // Local boolean variable keeping track if move has been made or not
                // Placing the token in the first available spot in column starting from bottom, if possible
                for(int i = 5; i >= 0; i--){
                    if(intCheckArr[i][0] == 0 && isDone == false){
                        intCheckArr[i][0] = 2; // Storing 2 to keep track that p2 has token here
                        lblTokenArr[i][0].setIcon(p2);  
                        
                        //lblToken.setLocation(621, 965);
                        isDone = true;
                    }
                }
                // Checking if anyone won with winner method
                winner();
            }
        } else if (intRandom == 2){
            // Only allowing click if the column is not full
            if(intCheckArr[0][1] == 0){
                // Increasing the integer variable storing the number of intClicks
                intClicks += 1;
                boolean isDone = false; // Local boolean variable keeping track if move has been made or not
                // Placing the token in the first available spot in column starting from bottom, if possible
                for(int i = 5; i >= 0; i--){
                    if(intCheckArr[i][1] == 0 && isDone == false){
                        intCheckArr[i][1] = 2; // Storing 2 to keep track that p2 has token here
                        lblTokenArr[i][1].setIcon(p2);  
                        
                        //lblToken.setLocation(621, 965);
                        isDone = true;
                    }
                }
                // Checking if anyone won with winner method
                winner();
            }
        } else if (intRandom == 3){
            // Only allowing click if the column is not full
            if(intCheckArr[0][2] == 0){
                // Increasing the integer variable storing the number of intClicks
                intClicks += 1;
                boolean isDone = false; // Local boolean variable keeping track if move has been made or not
                // Placing the token in the first available spot in column starting from bottom, if possible
                for(int i = 5; i >= 0; i--){
                    if(intCheckArr[i][2] == 0 && isDone == false){
                        intCheckArr[i][2] = 2; // Storing 2 to keep track that p2 has token here
                        lblTokenArr[i][2].setIcon(p2);  
                        
                        //lblToken.setLocation(621, 965);
                        isDone = true;
                    }
                }
                // Checking if anyone won with winner method
                winner();
            }
        } else if (intRandom == 4){
            // Only allowing click if the column is not full
            if(intCheckArr[0][3] == 0){
                // Increasing the integer variable storing the number of intClicks
                intClicks += 1;
                boolean isDone = false; // Local boolean variable keeping track if move has been made or not
                // Placing the token in the first available spot in column starting from bottom, if possible
                for(int i = 5; i >= 0; i--){
                    if(intCheckArr[i][3] == 0 && isDone == false){
                        intCheckArr[i][3] = 2; // Storing 2 to keep track that p2 has token here
                        lblTokenArr[i][3].setIcon(p2);  
                        
                        //lblToken.setLocation(621, 965);
                        isDone = true;
                    }
                }
                // Checking if anyone won with winner method
                winner();
            }
        } else if (intRandom == 5){
            // Only allowing click if the column is not full
            if(intCheckArr[0][4] == 0){
                // Increasing the integer variable storing the number of intClicks
                intClicks += 1;
                boolean isDone = false; // Local boolean variable keeping track if move has been made or not
                // Placing the token in the first available spot in column starting from bottom, if possible
                for(int i = 5; i >= 0; i--){
                    if(intCheckArr[i][4] == 0 && isDone == false){
                        intCheckArr[i][4] = 2; // Storing 2 to keep track that p2 has token here
                        lblTokenArr[i][4].setIcon(p2);  
                        
                        //lblToken.setLocation(621, 965);
                        isDone = true;
                    }
                }
                // Checking if anyone won with winner method
                winner();
            }
        } else if (intRandom == 6){
            // Only allowing click if the column is not full
            if(intCheckArr[0][5] == 0){
                // Increasing the integer variable storing the number of intClicks
                intClicks += 1;
                boolean isDone = false; // Local boolean variable keeping track if move has been made or not
                // Placing the token in the first available spot in column starting from bottom, if possible
                for(int i = 5; i >= 0; i--){
                    if(intCheckArr[i][5] == 0 && isDone == false){
                        intCheckArr[i][5] = 2; // Storing 2 to keep track that p2 has token here
                        lblTokenArr[i][5].setIcon(p2);  
                        
                        //lblToken.setLocation(621, 965);
                        isDone = true;
                    }
                }
                // Checking if anyone won with winner method
                winner();
            }
        } else if (intRandom == 7){
            // Only allowing click if the column is not full
            if(intCheckArr[0][5] == 0){
                // Increasing the integer variable storing the number of intClicks
                intClicks += 1;
                boolean isDone = false; // Local boolean variable keeping track if move has been made or not
                // Placing the token in the first available spot in column starting from bottom, if possible
                for(int i = 5; i >= 0; i--){
                    if(intCheckArr[i][5] == 0 && isDone == false){
                        intCheckArr[i][5] = 2; // Storing 2 to keep track that p2 has token here
                        lblTokenArr[i][5].setIcon(p2);  
                        
                        //lblToken.setLocation(621, 965);
                        isDone = true;
                    }
                }
                // Checking if anyone won with winner method
                winner();
            }
        }               
        
    }
    
    // Method which resets the round
    void reset(){
        // Resetting the check array
        for (int row = 0; row < 6; row++){
           for (int col = 0; col < 7; col++){
               intCheckArr[row][col] = 0;
           }
        }
        
        // Resetting the icons on the board
        for (int row = 0; row < 6; row++){
            for (int col = 0; col < 7; col++){
                lblTokenArr[row][col].setIcon(null);
            }
        }
        
        // Resetting variable which keep track of things
        intWin = 0;
        intClicks = 0;
        
        // Resetting strIntro variable
        strIntro = "";
        
        // Updating the colour of the slightly transparent tokens after each click
        // Setting up all the buttons to drop a token
        for (int i = 0; i < btnArr.length; i++){
            if (intClicks % 2 == 1){ // If it is player 1's turn
                btnArr[i].setIcon(p2Light); // Setting the button colours to chosen colour
            } else { // If it is player 2 or AI's turn
                btnArr[i].setIcon(p1Light); // Setting the button colours to unchosen colour               
            }
        }        
        
    }
    

   /**
    * // Method to reverse an inputted integer value
    * @param n is a number which will get stored in reverse in the strIntro variable
    */ 
    public static void flip(int n){
        if(n > 0){
            // Updating str intro variable
            strIntro += (n % 10) + " ";
            flip(n / 10);
        } 
    }
    
    // Method which saves high scores
    void save(){
        // Updating the arrays storing high scores with new data if the current score is higher        
        if(p1Arr.get(intP1Pos) < intP1Wins){
            p1Arr.set(intP1Pos, intP1Wins);
        }
        if(p2Arr.get(intP2Pos) < intP2Wins){
            p2Arr.set(intP2Pos, intP2Wins);
        }
        try{
            FileWriter fr = new FileWriter("p1Scores.txt");
            FileWriter fr2 = new FileWriter("p2Scores.txt");
            PrintWriter pr = new PrintWriter(fr);
            PrintWriter pr2 = new PrintWriter(fr2);
            
            // Updating the scores file by replcing text file
            for (int i = 0; i < p1Arr.size(); i++){
                pr.write(p1Arr.get(i) + "\n");
                pr2.write(p2Arr.get(i) + "\n");
            }                        
            pr.close();
            pr2.close();
            
        }
        catch (IOException e){}
    }
    

}
