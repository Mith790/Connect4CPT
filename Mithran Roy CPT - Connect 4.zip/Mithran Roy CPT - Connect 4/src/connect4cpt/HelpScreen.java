/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package connect4cpt;

import static connect4cpt.GameScreen.strP1Name;
import static connect4cpt.GameScreen.strP2Name;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextArea;

/**
 *
 * Author: Mithran Roy
 * Date: August 25th, 2020
 * Program which opens the help screen of the Connect 4 Game
 */
public class HelpScreen extends JFrame implements ActionListener{
    JLabel lblTitle; // This is the Title Label which shows the title image
    JLabel lblPhrase; // This is the Phrase Label says who the winner is
    JButton btnHome; // This is the button to bring up the opening screen
    JButton btnControls; // This is the button which allows users to check controls
    JButton btnObjective; // This is the button which allows user to learn the objective
    JButton btnAdditional; // This is the button for extra info 
    JLabel lblPhrase1; // This is where the first phrase will be shown
    JLabel lblPhrase2; // This is where the second phrase will be shown
    JLabel lblPhrase3; // This is where the third phrase will be shown
    // Creating an array to store all the instructions
    ArrayList<String> strInstructionsList = new ArrayList<String>();
    
    // Importing the image for the home button
    ImageIcon home = new ImageIcon("home.png");
    // Importing the title image
    ImageIcon title = new ImageIcon("title.png");
    
    public HelpScreen(){
        super("Connect 4 Help Screen"); // This will be displayed in the Title Bar
        //Setting up the screen
        resize(1920, 1080);
        //Creating a colour to match background with RGB values
        Color gray = new Color(238, 238, 238);
        // Setting the frame layout
        setLayout(null);
        
        
                try{
            FileReader fr = new FileReader("help.txt");
            BufferedReader br = new BufferedReader(fr);
            String strLine = br.readLine();//All the files keep
            //a system generated character to terminate a new line
            //when the line that read is a null then that's the end of tbe file
            while(strLine != null){
                strInstructionsList.add(strLine);
                strLine = br.readLine();
                
            }
            br.close();
        }
        catch (IOException e){}
                
        // Setting up an instance of the Title label
        lblTitle = new JLabel();
        // Setting the size of the label
        lblTitle.setSize(760, 240);
        // Choosing the location
        lblTitle.setLocation(580, 0);
        // Adding the title image to the label
        lblTitle.setIcon(title);
        // Adding the label to the JFrame
        add(lblTitle);
        
        // Setting up an instance of the Phrase label
        lblPhrase = new JLabel();
        // Setting the size of the label
        lblPhrase.setSize(960 ,300);
        // Choosing the location
        lblPhrase.setLocation(480, 150); 
        // Setting the text in the label        
        lblPhrase.setText("Click on one of the buttons below to learn about the game");                     
        // Changing font and font size of label
        lblPhrase.setFont(new Font("Helvetica", Font.BOLD, 35));
        // Adding the label to the JFrame
        add(lblPhrase);
        
        // Setting up an instance of the Home Button
        btnHome = new JButton();
        // Setting up the size of the button
        btnHome.setSize(100, 100);
        // Choosing the location
        btnHome.setLocation(0, 0);
        // Adding the home image to the label
        btnHome.setIcon(home);        
        // Making the button listen to user
        btnHome.setActionCommand("Home");
        btnHome.addActionListener(this); // Makes this button react to action command
        // Adding the button to the JFrame
        add(btnHome);
        
        // Setting up an instance of the Controls Button
        btnControls = new JButton();
        // Setting up the size of the button
        btnControls.setSize(200, 100);
        // Choosing the location
        btnControls.setLocation(860, 370);
        // Setting the text
        btnControls.setText("Controls");
        // Setting the font
        btnControls.setFont(new Font("Garamond", Font.BOLD, 35));
        // Making the button listen to user
        btnControls.setActionCommand("controls");
        btnControls.addActionListener(this); // Makes this button react to action command
        // Adding the button to the JFrame
        add(btnControls);
        
        // Setting up an instance of the Objective Button
        btnObjective = new JButton();
        // Setting up the size of the button
        btnObjective.setSize(200, 100);
        // Choosing the location
        btnObjective.setLocation(600, 370);
        // Setting the text
        btnObjective.setText("Objectives");
        // Setting the font
        btnObjective.setFont(new Font("Garamond", Font.BOLD, 35));
        // Making the button listen to user
        btnObjective.setActionCommand("objective");
        btnObjective.addActionListener(this); // Makes this button react to action command
        // Adding the button to the JFrame
        add(btnObjective);
        
        // Setting up an instance of the Additional Button
        btnAdditional = new JButton();
        // Setting up the size of the button
        btnAdditional.setSize(300, 100);
        // Choosing the location
        btnAdditional.setLocation(1120, 370);
        // Setting the text
        btnAdditional.setText("Additional Info");
        // Setting the font
        btnAdditional.setFont(new Font("Garamond", Font.BOLD, 35));
        // Making the button listen to user
        btnAdditional.setActionCommand("additional");
        btnAdditional.addActionListener(this); // Makes this button react to action command
        // Adding the button to the JFrame
        add(btnAdditional);
        
        // Setting up an instance of the Phrase1 label
        lblPhrase1 = new JLabel();
        // Setting the size of the label
        lblPhrase1.setSize(960 ,300);
        // Choosing the location
        lblPhrase1.setLocation(350, 450);
        // Setting the text in the label        
        lblPhrase1.setText("");           
        // Changing font and font size of label
        lblPhrase1.setFont(new Font("Helvetica", Font.BOLD, 35));
        // Adding the label to the JFrame
        add(lblPhrase1);
        
        // Setting up an instance of the Phrase2 label
        lblPhrase2 = new JLabel();
        // Setting the size of the label
        lblPhrase2.setSize(1200 ,300);
        // Choosing the location
        lblPhrase2.setLocation(350, 600);
        // Setting the text in the label        
        lblPhrase2.setText("");           
        // Changing font and font size of label
        lblPhrase2.setFont(new Font("Helvetica", Font.BOLD, 35));
        // Adding the label to the JFrame
        add(lblPhrase2);
        
        // Setting up an instance of the Phrase1 label
        lblPhrase3 = new JLabel();
        // Setting the size of the label
        lblPhrase3.setSize(1300 ,300);
        // Choosing the location
        lblPhrase3.setLocation(350, 750);
        // Setting the text in the label        
        lblPhrase3.setText("");           
        // Changing font and font size of label
        lblPhrase3.setFont(new Font("Helvetica", Font.BOLD, 35));
        // Adding the label to the JFrame
        add(lblPhrase3);
    }
    public void actionPerformed (ActionEvent e){
        // Checking if Home button was clicked
        if(e.getActionCommand().equals("Home")){
            // Resetting the player name and AI name variables
            strP1Name = "";
            strP2Name = "";
            // Resetting the AI difficulties
            OpeningScreen myFrame = new OpeningScreen();
            myFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // When users clicks the close button
            // JFrame will automatically exit
            myFrame.setVisible(true); // Displaying the new JFrame
            this.dispose(); // Closing the currently open frame
       }
       // Checking if an insructional button was clicked
       else{
            // Checking the array list with linear search
            for (int i = 0; i < 12; i++){
                // If the number matches a button command, show the appropriate instuctions as stored in the file
                if (strInstructionsList.get(i).equals(e.getActionCommand())){
                    lblPhrase1.setText(strInstructionsList.get(i+1));
                    lblPhrase2.setText(strInstructionsList.get(i+2));
                    lblPhrase3.setText(strInstructionsList.get(i+3));
                } 
            }
        }
}
}
