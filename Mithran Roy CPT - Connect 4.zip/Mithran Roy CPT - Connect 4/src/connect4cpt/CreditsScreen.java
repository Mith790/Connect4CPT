/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package connect4cpt;

import static connect4cpt.GameScreen.strP1Name;
import static connect4cpt.GameScreen.strP2Name;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

/**
 *
 * Author: Mithran Roy
 * Date: August 25th, 2020
 * A class which opens the credits screen of the game
 */
// Extending an abstract class
public class CreditsScreen extends AbstractScreen{
      
    public CreditsScreen(){
        // Setting up an instance of the Image label
        lblImage = new JLabel();
        // Setting the size of the label
        lblImage.setSize(1920, 1080);
        // Choosing the location
        lblImage.setLocation(0, 0);
        // Adding the title image to the label
        lblImage.setIcon(credits);
        // Adding the label to the JFrame
        add(lblImage);
        popUp();
    }
    
    // Sending a pop up message with this method
    public void popUp() {
        JOptionPane.showMessageDialog(null, "Special thanks to Bitmoji too");  
    }
    
    
    public void actionPerformed (ActionEvent e){
        // Checking if Home button was clicked
        if(e.getActionCommand().equals("Home")){
            // Resetting the player name and AI name variables
            strP1Name = "";
            strP2Name = "";
            // Resetting the AI difficulties
            OpeningScreen myFrame = new OpeningScreen();
            myFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // When users clicks the close button
            // JFrame will automatically exit
            myFrame.setVisible(true); // Displaying the new JFrame
            this.dispose(); // Closing the currently open frame
       }
    }
} 
