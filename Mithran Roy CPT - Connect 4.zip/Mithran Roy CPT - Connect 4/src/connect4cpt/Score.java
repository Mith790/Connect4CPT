/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package connect4cpt;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

/**
 *
 * Author: Mithran Roy
 * Date: August 25th, 2020
 * Daughter class of ScoreGiver
 */
public class Score {
    // Declaring the integer variable which will store the highscore
    int intHighScore;
    
    
    // Declaring the array list which will store the scores of all the character
    //static ArrayList<String> strList1 = new ArrayList<String>();
    static ArrayList<Integer> intP1List = new ArrayList<Integer>();
    static ArrayList<Integer> intP2List = new ArrayList<Integer>();
    
    private ArrayList intPNum1List;
    
    public static void main(String [] args){
        
    }
    
    // Method to get player number
    public Score(int intPNum){
        intPNum1List = new ArrayList(intPNum);            
        
    }    

}
